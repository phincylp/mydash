/*
 * Copyright (c) 2008-2009 by Robert Scheck <apache@robert-scheck.de>
 * Based on mod_security by Breach Security Inc. <support@breach.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 only
 * as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * For the inclusion of mod_log_post into Linux distributions, please
 * read section 4.0 of the README file as well as LICENSING_EXCEPTION
 * file very carefully and honor it.
 */

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>

#ifdef WIN32
#include <direct.h>
#else
#include <sys/types.h>
#include <unistd.h>
#endif

#if !defined(OS2) && !defined(WIN32) && !defined(BEOS) && !defined(NETWARE)
#include "unixd.h"
#define __SET_MUTEX_PERMS
#endif

#include "ap_config.h"
#include "httpd.h"
#include "http_config.h"
#include "http_request.h"
#include "http_core.h"
#include "http_log.h"
#include "http_protocol.h"
#include "ap_mpm.h"

#include "apr.h"
#include "apr_strings.h"
#include "apr_user.h"
#include "apr_lib.h"
#include "apr_signal.h"
#include "apr_global_mutex.h"

#if (defined(AP_REG_ICASE) || (MODULE_MAGIC_NUMBER >= 20050127))
#define regex_t ap_regex_t
#define regmatch_t ap_regmatch_t
#define REG_EXTENDED AP_REG_EXTENDED
#define REG_NOSUB AP_REG_NOSUB
#define REG_ICASE AP_REG_ICASE
#define REG_NOMATCH AP_REG_NOMATCH
#endif

#if !defined(O_BINARY)
#define O_BINARY (0)
#endif

module AP_MODULE_DECLARE_DATA log_post_module;

static apr_global_mutex_t *modsec_auditlog_lock = NULL;
static ap_filter_rec_t *global_sec_filter_in;

#define CREATEMODE ( APR_UREAD | APR_UWRITE | APR_GREAD )

#if defined(NETWARE)
#define CREATEMODE_UNISTD ( S_IREAD | S_IWRITE )
#elif defined(WIN32)
#define CREATEMODE_UNISTD ( _S_IREAD | _S_IWRITE )
#else
#define CREATEMODE_UNISTD ( S_IRUSR | S_IWUSR | S_IRGRP )
#endif

#define MODSEC_SKIP                 -2000
#define MODSEC_ALLOW                -2001

#define NOT_SET                     -1
#define NOT_SET_P                   (void *)-1

#define VAR_ACTION_ALLOW            1
#define VAR_ACTION_DENY             0

#define VAR_UNKNOWN                 0
#define VAR_ARG                     1
#define VAR_HEADER                  2
#define VAR_ENV                     3
#define VAR_ARGS                    4
#define VAR_POST_PAYLOAD            5
#define VAR_ARGS_NAMES              6
#define VAR_ARGS_VALUES             7
#define VAR_ARGS_SELECTIVE          8
#define VAR_OUTPUT                  9
#define VAR_COOKIES_NAMES           10
#define VAR_COOKIES_VALUES          11
#define VAR_COOKIE                  12
#define VAR_HEADERS                 13
#define VAR_HEADERS_COUNT           14
#define VAR_HEADERS_NAMES           15
#define VAR_HEADERS_VALUES          16
#define VAR_FILES_COUNT             17
#define VAR_FILES_NAMES             18
#define VAR_FILES_SIZES             19
#define VAR_ARGS_COUNT              20
#define VAR_REMOTE_ADDR             21
#define VAR_REMOTE_HOST             22
#define VAR_REMOTE_USER             23
#define VAR_REMOTE_IDENT            24
#define VAR_REQUEST_METHOD          25
#define VAR_SCRIPT_FILENAME         26
#define VAR_PATH_INFO               27
#define VAR_QUERY_STRING            28
#define VAR_AUTH_TYPE               29
#define VAR_DOCUMENT_ROOT           30
#define VAR_SERVER_ADMIN            31
#define VAR_SERVER_NAME             32
#define VAR_SERVER_ADDR             33
#define VAR_SERVER_PORT             34
#define VAR_SERVER_PROTOCOL         35
#define VAR_SERVER_SOFTWARE         36
#define VAR_TIME_YEAR               37
#define VAR_TIME_MON                38
#define VAR_TIME_DAY                39
#define VAR_TIME_HOUR               40
#define VAR_TIME_MIN                41
#define VAR_TIME_SEC                42
#define VAR_TIME_WDAY               43
#define VAR_TIME                    44
#define VAR_API_VERSION             45
#define VAR_THE_REQUEST             46
#define VAR_REQUEST_URI             47
#define VAR_REQUEST_FILENAME        48
#define VAR_IS_SUBREQ               49
#define VAR_HANDLER                 50
#define VAR_SCRIPT_UID              51
#define VAR_SCRIPT_GID              52
#define VAR_SCRIPT_USERNAME         53
#define VAR_SCRIPT_GROUPNAME        54
#define VAR_SCRIPT_MODE             55
#define VAR_COOKIES_COUNT           56
#define VAR_FILE_NAME               57
#define VAR_FILE_SIZE               58
#define VAR_OUTPUT_STATUS           59
#define VAR_REQUEST_BASENAME        60
#define VAR_SCRIPT_BASENAME         61

#define MULTIPART_BUF_SIZE          4096

#define REQBODY_FILE_NONE           0
#define REQBODY_FILE_DELETE         1
#define REQBODY_FILE_LEAVE          2

#define MULTIPART_FORMDATA          1
#define MULTIPART_FILE              2

#define POST_ON_DISK                1
#define POST_IN_MEMORY              2

#define FATAL_ERROR                 "Unable to allocate memory"

#define UNKNOWN_CSID    0
#define MB_CSID         800         /* First multibyte character set */
#define UNI3_CSID       873         /* Unicode 3.x character set ID  */
#define SJIS1_CSID      832         /* SJIS character set ID         */
#define SJIS2_CSID      834         /* SJIS+YEN character set ID     */
#define BIG5_CSID       865         /* BIG5 character set ID         */
#define GBK_CSID        852         /* GBK character set ID          */
#define GB2312_CSID     850         /* GB2312 character set ID       */
#define ZHT32EUC_CSID   860         /* Chinese 4-byte character set  */
#define JEUC1_CSID      830         /* JEUC character set ID         */
#define JEUC2_CSID      831         /* JEUC+YEN character set ID     */
#define JA16VMS_CSID    829         /* VMS 2-byte Japanese           */

#define INHERITANCE_IMPORT          1
#define INHERITANCE_REMOVE          2

#define PHASE_INPUT                 0
#define PHASE_OUTPUT                1

static const char * const all_variables[] = {
    "UNKOWN",
    "ARG",
    "HEADER",
    "ENV",
    "ARGS",
    "POST_PAYLOAD",
    "ARGS_NAMES",
    "ARGS_VALUES",
    "ARGS_SELECTIVE",
    "OUTPUT",
    "COOKIES_NAMES",    /* 10 */
    "COOKIES_VALUES",
    "COOKIE",
    "HEADERS",
    "HEADERS_COUNT",
    "HEADERS_NAMES",
    "HEADERS_VALUES",
    "FILES_COUNT",
    "FILES_NAMES",
    "FILES_SIZES",
    "ARGS_COUNT",       /* 20 */
    "REMOTE_ADDR",
    "REMOTE_HOST",
    "REMOTE_USER",
    "REMOTE_IDENT",
    "REQUEST_METHOD",
    "SCRIPT_FILENAME",
    "PATH_INFO",
    "QUERY_STRING",
    "AUTH_TYPE",
    "DOCUMENT_ROOT",    /* 30 */
    "SERVER_ADMIN",
    "SERVER_NAME",
    "SERVER_ADDR",
    "SERVER_PORT",
    "SERVER_PROTOCOL",
    "SERVER_SOFTWARE",
    "TIME_YEAR",
    "TIME_MON",
    "TIME_DAY",
    "TIME_HOUR",        /* 40 */
    "TIME_MIN",
    "TIME_SEC",
    "TIME_WDAY",
    "TIME",
    "API_VERSION",
    "THE_REQUEST",
    "REQUEST_URI",
    "REQUEST_FILENAME",
    "IS_SUBREQ",
    "HANDLER",          /* 50 */
    "SCRIPT_UID",
    "SCRIPT_GID",
    "SCRIPT_USERNAME",
    "SCRIPT_GROUPNAME",
    "SCRIPT_MODE",
    "COOKIES_COUNT",
    "FILE_NAME",
    "FILE_SIZE",
    "OUTPUT_STATUS",
    "REQUEST_BASENAME", /* 60 */
    "SCRIPT_BASENAME",
    NULL
};

typedef struct {
    char *name;
    int type;
    int action;
} variable;

typedef struct {
    int auditlog;
    int skip_count;
    char *id;
    char *msg;
    char *rev;
    int mandatory;
    int logparts;
    char *logparts_value;
} actionset_t;

typedef struct sec_dir_config sec_dir_config;

typedef struct signature signature;
struct signature {
    actionset_t *actionset;
    char *pattern;
    regex_t *regex;
    int is_selective;
    int is_negative;
    int is_allow;

    /* 0 if this is a request rule, 1 is it is a response rule */
    int is_output;

    /* 0 for normal rules, INHERITANCE_IMPORT if this rule is only
     * a placeholder for a rule that will be imported from the
     * parent context at runtime, or INHERITANCE_REMOVE if this rule
     * is only a placeholder for a rule that will be removed from the
     * configuration at runtime.
     */
    int is_inheritance_placeholder;

    /* the ID of the rule that is being explicitly imported or removed */
    const char *inheritance_id;

    int requires_parsed_args;
    apr_array_header_t *variables;

    signature *first_sig_in_chain;
};

struct sec_dir_config {
    apr_pool_t *p;
    int filter_engine;
    int configuration_helper;
    int scan_post;
    actionset_t *actionset;
    actionset_t *actionset_signatures;
    apr_array_header_t *signatures;
    char *path;


    /* -- Audit log -- */

    /* The name of the audit log file (for the old type), or the
     * name of the index file (for the new audit log type)
     */
    char *auditlog_name;

    /* The file descriptor for the file above */
    apr_file_t *auditlog_fd;


    /* -- Debug log -- */

    int filter_debug_level;
    char *debuglog_name;
    apr_file_t *debuglog_fd;


    int charset_id;
    int multibyte_replacement_byte;


    /* -- Rule inheritance -- */

    /* This array holds the list of mandatory signatures
     * inherited from the parent context.
     */
    apr_array_header_t *inherited_mandatory_signatures;
};

typedef struct sec_filter_in_ctx_ {
    char *buffer;
    int type; /* POST_ON_DISK or POST_IN_MEMORY */
    int is_multipart;
    unsigned long int buflen; /* max. size of the buffer */
    unsigned long int bufleft; /* space left in buffer */
    unsigned long int sofar; /* data read sofar */
    int access_check_performed;
    apr_bucket_brigade *pbbTmp;
    char *output_ptr;
    unsigned long int output_sent;
    int done_reading;
    int done_writing;
    char *tmp_file_name;
    int tmp_file_fd;
    int tmp_file_mode;
    int is_put;
} sec_filter_in_ctx;

typedef struct modsec_rec modsec_rec;

typedef struct {
    /* part type, can be MULTIPART_FORMDATA or MULTIPART_FILE */
    int type;
    /* the name */
    char *name;

    /* variables only, variable value */
    char *value;
    apr_array_header_t *value_parts;

    /* files only, the content type (where available) */
    char *content_type;

    /* files only, the name of the temporary file holding data */
    char *tmp_file_name;
    int tmp_file_fd;
    unsigned tmp_file_size;
    /* files only, filename as supplied by the browser */
    char *filename;

    char *last_header_name;
    apr_table_t *headers;
} multipart_part;

typedef struct {
    modsec_rec *msr;
    request_rec *r;
    sec_dir_config *dcfg;
    apr_pool_t *p;

    /* this array keeps parts */
    apr_array_header_t *parts;

    /* mime boundary used to detect when
     * parts end and new begin
     */
    char *boundary;

    /* internal buffer and other variables
     * used while parsing
     */
    char buf[MULTIPART_BUF_SIZE + 2];
    int buf_contains_line;
    char *bufptr;
    int bufleft;

    /* pointer that keeps track of a part while
     * it is being built
     */
    multipart_part *mpp;


    /* part parsing state; 0 means we are reading
     * headers, 1 means we are collecting data
     */
    int mpp_state;

    /* because of the way this parsing algorithm
     * works we hold back the last two bytes of
     * each data chunk so that we can discard it
     * later if the next data chunk proves to be
     * a boundary; the first byte is an indicator
     * 0 - no content, 1 - two data bytes available
     */
    char reserve[4];

    int seen_data;
    int is_complete;
} multipart_data;

struct modsec_rec {
    request_rec *r;
    char *request_uri;
    char *_post_payload;
    char *_fake_post_payload;
    int should_body_exist;
    int is_body_read;
    unsigned long _post_len;
    sec_dir_config *dcfg;
    apr_table_t *parsed_args;
    apr_table_t *parsed_cookies;
    char *tmp_message;
    multipart_data *mpd;

    /* positive if relevant, zero or negative otherwise */
    int is_relevant;

    /* NOT_SET (-1) do nothing, 0 suppress audit logging, 1 force audit logging */
    int explicit_auditlog;

    /* whether or not the current request is dynamic; this field
     * is NOT_SET by default because sometimes we don't need to
     * know (and finding out is expensive). Therefore the possible
     * values are NOT_SET (we don't know), 0, and 1.
     */
    int is_dynamic;
    int is_enabled;

    sec_filter_in_ctx *ctx_in;

    char *new_auditlog_boundary;

    apr_time_t time_checkpoint_1;
    apr_time_t time_checkpoint_2;
    apr_time_t time_checkpoint_3;

    apr_array_header_t *messages;

    const char *cache_request_uri;
    const char *cache_path_info;
    const char *cache_the_request;
    const char *cache_query_string;
    const char *cache_request_basename;
    const char *cache_script_basename;

    apr_table_t *cache_headers_in;
};

typedef struct {
    char *data;
    long int length;
} data_chunk;

static int check_sig_against_string(modsec_rec *msr, signature *_sig, const char *s, int var_type, char *var_name);
static void sec_debug_log(request_rec *r, int level, const char *text, ...);

static char *normalise_inplace(request_rec *r, sec_dir_config *dcfg, char *uri, char **error_msg);
static char *normalise(request_rec *r, sec_dir_config *dcfg, char *_uri, char **error_msg);
static char *normalise_relaxed_inplace(request_rec *r, sec_dir_config *dcfg, char *uri, char **error_msg);
static char *normalise_relaxed(request_rec *r, sec_dir_config *dcfg, char *_uri, char **error_msg);
static char *normalise_other_inplace(request_rec *r, sec_dir_config *dcfg, char *uri, char **error_msg);
static char *normalise_urlencoding_relaxed_inplace(request_rec *r, sec_dir_config *dcfg, char *uri, char **error_msg);
static char *normalise_urlencoding_inplace(request_rec *r, sec_dir_config *dcfg, char *uri, char **error_msg);

static int check_single_signature(modsec_rec *msr, signature *sig);
static int _check_single_signature(modsec_rec *msr, signature *sig, char **error_msg);
static char *get_env_var(request_rec *r, char *name);
static const char *get_variable(modsec_rec *msr, variable *v, int var_type);

static char *remove_binary_content(request_rec *r, char *data, long size);
static int parse_arguments(char *s, apr_table_t *parsed_args, request_rec *r, sec_dir_config *dcfg, char **error_msg);

static void sec_set_dir_defaults(sec_dir_config *dcfg);

static modsec_rec *sec_create_context(request_rec *r);
static int sec_initialise(modsec_rec *msr);
static int sec_check_access(request_rec *r);
static int sec_check_all_signatures(modsec_rec *msr);

static int multipart_init(multipart_data *mpd, modsec_rec *msr, char **error_msg);
static int multipart_complete(multipart_data *mpd, char **error_msg);
static apr_status_t multipart_cleanup(void *data);
static apr_status_t request_body_file_cleanup(void *data);
static int multipart_process_chunk(multipart_data *mpd, const char *buf, unsigned int size, char **error_msg);
static int multipart_process_part_header(multipart_data *mpd, char **error_msg);
static int multipart_process_part_data(multipart_data *mpd, char **error_msg);
static int multipart_parse_content_disposition(multipart_data *mpd, char *value);
static int multipart_process_boundary(multipart_data *mpd, int last_part, char **error_msg);
static int multipart_get_variables(multipart_data *mpd, apr_table_t *parsed_args, sec_dir_config *dcfg, char **error_msg);
static int multipart_contains_files(multipart_data *mpd);
static multipart_part *multipart_get_part(multipart_data *mpd, char *name);
static int multipart_check_files_names(modsec_rec *msr, signature *sig, variable *var);
static int multipart_check_files_sizes(modsec_rec *msr, signature *sig, variable *var);

static int sec_mkstemp(char *template);
static char *log_escape(apr_pool_t *p, char *text);
static char *log_escape_nq(apr_pool_t *p, char *text);
static char *_log_escape(apr_pool_t *p, char *text, int escape_quotes, int escape_colon);

static char *filter_multibyte_inplace(int cs_id, char replacement_byte, char *outbuf);
static char *filter_multibyte_other(int charset_id, char replacement_byte, char *inptr);
static char *filter_multibyte_unicode(int charset_id, char replacement_byte, char *inptr);

static int perform_action(modsec_rec *msr, actionset_t *dcfg_actionset, signature *sig);
static char *construct_fake_urlencoded(modsec_rec *msr, apr_table_t *args);
static int sec_table_count(apr_table_t *table);
static char *construct_rule_metadata(modsec_rec *msr, actionset_t *actionset, signature *sig);

static int sec_audit_logger_serial(request_rec *r, request_rec *origr, sec_dir_config *dcfg, modsec_rec *msr);
static void sec_auditlog_init(modsec_rec *msr);

static void store_msr(request_rec *r, modsec_rec *msr);
static modsec_rec *find_msr(request_rec *r);

static char *bytes2hex(apr_pool_t *pool, unsigned char *data, int len);
static unsigned char x2c(unsigned char *what);
static unsigned char *c2x(unsigned what, unsigned char *where);
static char *get_temp_folder(apr_pool_t *p);
static char *get_apr_error(apr_pool_t *p, apr_status_t rc);
static char *construct_put_filename(modsec_rec *msr);

static char *current_logtime(request_rec *r);
static char *current_filetime(request_rec *r);
static char *create_auditlog_boundary(request_rec *r);

static void sec_time_checkpoint(modsec_rec *msr, int checkpoint_no);
static actionset_t *merge_actionsets(apr_pool_t *pool, actionset_t *parent, actionset_t *child);
static int sec_remove_lf_crlf_inplace(char *text);
static int is_token_char(char c);
static const char *get_response_protocol(request_rec *r);
static void init_empty_actionset(actionset_t *actionset);
static void init_default_actionset(actionset_t *actionset);

/* ----------------------------------------------------------------------------- */

void init_empty_actionset(actionset_t *actionset) {
    memset(actionset, 0, sizeof(actionset_t));
    actionset->auditlog = NOT_SET;
    actionset->id = NULL;
    actionset->rev = NULL;
    actionset->msg = NULL;
    actionset->skip_count = 1;
}

void init_default_actionset(actionset_t *actionset) {
    memset(actionset, 0, sizeof(actionset_t));
    actionset->auditlog = NOT_SET;
}

int is_token_char(char c) {
    /* CTLs not allowed */
    if ((c <= 32)||(c >= 127)) return 0;
    switch(c) {
        case '(' :
        case ')' :
        case '<' :
        case '>' :
        case '@' :
        case ',' :
        case ';' :
        case ':' :
        case '\\' :
        case '"' :
        case '/' :
        case '[' :
        case ']' :
        case '?' :
        case '=' :
            return 0;
    }
    return 1;
}

int sec_remove_lf_crlf_inplace(char *text) {
    char *p = text;
    int count = 0;

    if (text == NULL) return -1;

    while(*p != '\0') {
        count++;
        p++;
    }

    if (count > 0) {
        if (*(p - 1) == '\n') {
            *(p - 1) = '\0';
            if (count > 1) {
                if (*(p - 2) == '\r') *(p - 2) = '\0';
            }
        }
    }

    return 1;
}

/**
 * Creates a random 8-character string that
 * consists of hexadecimal numbers, to be used
 * as an audit log boundary.
 */
char *create_auditlog_boundary(request_rec *r) {
    unsigned long data = rand();
    return bytes2hex(r->pool, (unsigned char *)&data, 4);
}

/**
 * Converts a series of bytes into its hexadecimal
 * representation.
 */
char *bytes2hex(apr_pool_t *pool, unsigned char *data, int len) {
    static unsigned char b2hex[] = "0123456789abcdef";
    char *hex = apr_palloc(pool, (len * 2) + 1);
    int i, j;

    if (hex == NULL) return NULL;

    j = 0;
    for(i = 0; i < len; i++) {
        hex[j++] = b2hex[data[i] >> 4];
        hex[j++] = b2hex[data[i] & 0x0f];
    }
    hex[j] = 0;

    return hex;
}

/**
 * Converts a byte given as its hexadecimal representation
 * into a proper byte. Does not check for overflows.
 */
unsigned char x2c(unsigned char *what) {
    register unsigned char digit;

    digit = (what[0] >= 'A' ? ((what[0] & 0xdf) - 'A') + 10 : (what[0] - '0'));
    digit *= 16;
    digit += (what[1] >= 'A' ? ((what[1] & 0xdf) - 'A') + 10 : (what[1] - '0'));

    return digit;
}

/**
 * Converts a single byte into its hexadecimal representation.
 * Will overwrite two bytes at the destination.
 */
unsigned char *c2x(unsigned what, unsigned char *where) {
    static const char c2x_table[] = "0123456789abcdef";

    what = what & 0xff;
    *where++ = c2x_table[what >> 4];
    *where++ = c2x_table[what & 0x0f];

    return where;
}

char *get_temp_folder(apr_pool_t *p) {
    char *filename = NULL;

    #ifdef WIN32
    filename = apr_pcalloc(p, 256);
    if (filename == NULL) return "";
    if (GetTempPath(255, filename) != 0) return filename;
    #endif

    filename = getenv("TMPDIR");
    if (filename != NULL) return filename;

    filename = getenv("TEMP");
    if (filename != NULL) return filename;

    filename = getenv("TMP");
    if (filename != NULL) return filename;

    #if defined NETWARE
    return("sys:/tmp/");
    #elif defined WIN32
    return("");
    #else
    return("/tmp/");
    #endif
}

/**
 * Returns a new string that contains the error
 * message for the given return code.
 */
char *get_apr_error(apr_pool_t *p, apr_status_t rc) {
    char *text = apr_pcalloc(p, 201);
    if (text == NULL) return NULL;
    apr_strerror(rc, text, 200);
    return text;
}

/**
 * Counts the number of entries in the given APR
 * table.
 */
int sec_table_count(apr_table_t *table) {
    const apr_array_header_t *arr;
    if (table == NULL) return 0;
    arr = apr_table_elts(table);
    return arr->nelts;
}

char *construct_fake_urlencoded(modsec_rec *msr, apr_table_t *args) {
    apr_table_entry_t *te;
    const apr_array_header_t *arr;
    int k;
    char *body;
    unsigned int body_len;

    if (args == NULL) return NULL;

    /* calculate buffer size */
    body_len = 1;
    arr = apr_table_elts(args);
    te = (apr_table_entry_t *)arr->elts;
    for(k = 0; k < arr->nelts; k++) {
        body_len += 4;
        body_len += strlen(te[k].key);
        body_len += strlen(te[k].val);
    }

    /* allocate the buffer */
    body = apr_palloc(msr->r->pool, body_len + 1);
    if ((body == NULL)||(body_len + 1 == 0)) return NULL;
    *body = 0;

    /* loop through the variables
     * and create a single string out of them
     */
    arr = apr_table_elts(args);
    te = (apr_table_entry_t *)arr->elts;
    for(k = 0; k < arr->nelts; k++) {
        if (*body != 0) {
            strncat(body, "&", body_len - strlen(body));
        }
        strncat(body, te[k].key, body_len - strlen(body));
        strncat(body, "=", body_len - strlen(body));
        strncat(body, te[k].val, body_len - strlen(body));
    }

    return body;
}

char *construct_rule_metadata(modsec_rec *msr, actionset_t *_actionset, signature *sig) {
    char *id = "", *rev = "", *msg = "", *severity = "";
    actionset_t *actionset = _actionset;

    /* If we were called because of a match in a rule
     * that is part of a chain, look up the first rule
     * in the chain to find the meta data.
     */
    if ((sig != NULL)
        &&(sig->first_sig_in_chain != NULL)
        &&(sig->first_sig_in_chain->actionset != NULL)
    ) {
        actionset = sig->first_sig_in_chain->actionset;
    }

    if (actionset->id != NULL) id = apr_psprintf(msr->r->pool, " [id \"%s\"]", log_escape(msr->r->pool, actionset->id));
    if (actionset->rev != NULL) rev = apr_psprintf(msr->r->pool, " [rev \"%s\"]", log_escape(msr->r->pool, actionset->rev));
    if (actionset->msg != NULL) msg = apr_psprintf(msr->r->pool, " [msg \"%s\"]", log_escape(msr->r->pool, actionset->msg));

    return apr_pstrcat(msr->r->pool, id, rev, msg, severity, NULL);
}

actionset_t *merge_actionsets(apr_pool_t *p, actionset_t *parent, actionset_t *child) {
    actionset_t *actionset = apr_pcalloc(p, sizeof(actionset_t));
    if (actionset == NULL) return NULL;

    /* start with the parent */
    memcpy(actionset, parent, sizeof(actionset_t));

    /* these actions are always allowed, and can only be set per-rule */
    if (child->id != NULL) actionset->id = child->id;
    if (child->rev != NULL) actionset->rev = child->rev;
    if (child->msg != NULL) actionset->msg = child->msg;
    if (child->mandatory) actionset->mandatory = child->mandatory;
    if (child->auditlog != NOT_SET) actionset->auditlog = child->auditlog;
    if (child->logparts != NOT_SET) {
        actionset->logparts = child->logparts;
        actionset->logparts_value = child->logparts_value;
    }

    return actionset;
}

int perform_action(modsec_rec *msr, actionset_t *dcfg_actionset, signature *sig) {
    actionset_t *actionset = dcfg_actionset;
    char *message = NULL;
    request_rec *r = msr->r;
    int rc = OK;

    /* Use the per-signature actionset if available */
    if ((sig != NULL)&&(sig->actionset != NULL)) {
        actionset = sig->actionset;
    }

    if (msr->tmp_message == NULL) {
        msr->tmp_message = "Unknown error";
    }

    /* is audit logging explicitly configured? */
    if (actionset->auditlog != NOT_SET) {
        msr->explicit_auditlog = actionset->auditlog;
    }

    message = apr_psprintf(r->pool, "Warning. %s%s", msr->tmp_message, construct_rule_metadata(msr, actionset, sig));
    rc = OK;

    msr->is_relevant++;

    if ((rc != OK)&&(rc != MODSEC_ALLOW)&&(rc != MODSEC_SKIP)) {
        char *action = apr_psprintf(msr->r->pool, "%i", rc);
        apr_table_setn(r->headers_in, "action", action);
    }

    msr->tmp_message = NULL;
    return rc;
}

int sec_mkstemp(char *template) {
    #if !(defined(WIN32)||defined(NETWARE))
    return mkstemp(template);
    #else
    if (mktemp(template) == NULL) return -1;
    return open(template, O_WRONLY | O_APPEND | O_CREAT | O_BINARY, CREATEMODE_UNISTD);
    #endif
}

#ifdef WIN32

char *strtok_r(char *s, const char *sep, char **lasts) {
    char *sbegin, *send;

    /* These two parameters must always be valid */
    if ((sep == NULL)||(lasts == NULL)) return NULL;

    /* Either of the following two must not be NULL */
    if ((s == NULL)&&(*lasts == NULL)) return NULL;

    sbegin = s ? s : *lasts;

    /* Advance through the separator at the beginning */
    sbegin += strspn(sbegin, sep);
    if (*sbegin == '\0') {
        *lasts = NULL;
        return NULL;
    }

    /* Find the next separator */
    send = strpbrk(sbegin, sep);
    if (send != NULL) *send++ = 0;
    *lasts = send;

    return sbegin;
}

#endif

char *filter_multibyte_unicode(int charset_id, char replacement_byte, char *inptr) {
    char *outptr = inptr;
    int i, j, k, n;

    i = strlen(inptr);
    j = 0;

    /* Unicode */
    while(j < i) {
        k = inptr[j] & 0xFF;
        if (k < 0x80) {
            j++;
            *outptr++ = (char)k;
        }
        else if (k < 0xC0) {
            j++;
            *outptr++ = replacement_byte;
        }
        else {
            if (k < 0xE0) n = 2;
            else if (k < 0xF0) n = 3;
            else if (k < 0xF8) n = 4;
            else if (k < 0xFC) n = 5;
            else if (k < 0xFE) n = 6;
            else n = 1;

            if (i - j >= n) {
                j += n;
            }
            else {
                i = j;
            }

            *outptr++ = replacement_byte;
        }
    }

    *outptr = 0;
    return inptr;
}

char *filter_multibyte_other(int charset_id, char replacement_byte, char *inptr) {
    char *outptr = inptr;
    int i, j, k, n;

    i = strlen(inptr);
    j = 0;

    while(j < i) {
        k = inptr[j] & 0xFF;
        if (k < 0x80) {
            j++;
            *outptr++ = (char)k;
        }
        else {
            n = 2;

            if ((k == 0x8E)&&(charset_id == ZHT32EUC_CSID)) {
                n = 4;
            }
            else if ((k == 0x8F)&&((charset_id == JEUC1_CSID)||(charset_id == JEUC2_CSID))) {
                n = 3;
            }
            else if ( ((k == 0x80)||(k == 0xFF))
                    && ((charset_id == BIG5_CSID)||(charset_id == GBK_CSID)||(charset_id == GB2312_CSID)) ) {
                n = 1;
            }
            else if ( ((k == 0x80)||((k >= 0xA0) && (k < 0xE0)))
                    && ((charset_id == SJIS1_CSID)||(charset_id == SJIS2_CSID)) ) {
                n = 1;
            }

            if (i - j >= n) {
                j += n;
            }
            else {
                i = j;
            }

            *outptr++ = (n == 1) ? (char)k : replacement_byte;
        }
    }

    *outptr = 0;
    return inptr;
}

char *filter_multibyte_inplace(int charset_id, char replacement_byte, char *inptr) {
    if (charset_id < MB_CSID) return inptr; /* not multibyte charset */
    if (charset_id == UNI3_CSID) return filter_multibyte_unicode(charset_id, replacement_byte, inptr);
    else return filter_multibyte_other(charset_id, replacement_byte, inptr);
}

char *get_env_var(request_rec *r, char *name) {
    char *result = (char *)apr_table_get(r->notes, name);

    if (result == NULL) {
        result = (char *)apr_table_get(r->subprocess_env, name);
    }

    if (result == NULL) {
        result = getenv(name);
    }

    return result;
}

const char *get_variable(modsec_rec *msr, variable *v, int var_type) {
    request_rec *r = msr->r;
    sec_dir_config *dcfg_proper = msr->dcfg;
    sec_dir_config *dcfg = (sec_dir_config *)apr_pcalloc(r->pool, sizeof(sec_dir_config));
    char *my_error_msg = NULL;
    const char *result = NULL;
    struct tm *tm;
    time_t tc;

    /* As of 1.8.6 validation is only done at the beginning of
     * request processing (and for all request data). Which means
     * we need to disable it here. Normalisation will be performed
     * as usual.
     */
    memcpy(dcfg, dcfg_proper, sizeof(sec_dir_config));

    switch (var_type) {

        case VAR_ARG :
            /* we don't normalise parameter values becaue
             * they are stored normalised
             */
            result = apr_table_get(msr->parsed_args, v->name);
            break;

        case VAR_HEADER :
            result = apr_table_get(msr->cache_headers_in, v->name);
            break;

        case VAR_ENV :
            result = apr_table_get(r->notes, v->name);

            if (result == NULL) {
                result = apr_table_get(r->subprocess_env, v->name);
            }

            if (result == NULL) {
                result = getenv(v->name);
            }
            break;

        case VAR_REMOTE_ADDR :
            result = r->connection->remote_ip;
            break;

        case VAR_REMOTE_HOST :
            result = ap_get_remote_host(r->connection, r->per_dir_config, REMOTE_NAME, NULL);
            break;

        case VAR_REMOTE_USER :
            result = r->user;
            break;

        case VAR_REMOTE_IDENT :
            result = ap_get_remote_logname(r);
            break;

        case VAR_REQUEST_METHOD :
            result = r->method;
            break;

        case VAR_REQUEST_URI :
            if (msr->cache_request_uri != NULL) result = msr->cache_request_uri;
            else {
                result = r->unparsed_uri;
                if (result != NULL) {
                    result = normalise(r, dcfg, (char *)result, &my_error_msg);
                    msr->cache_request_uri = result;
                }
            }
            break;

        case VAR_AUTH_TYPE :
            result = r->ap_auth_type;
            break;

        case VAR_IS_SUBREQ :
            result = (r->main != NULL ? "true" : "false");
            break;

        case VAR_DOCUMENT_ROOT :
            result = ap_document_root(r);
            break;

        case VAR_SERVER_ADMIN :
            result = r->server->server_admin;
            break;

        case VAR_SERVER_NAME :
            result = ap_get_server_name(r);
            break;

        case VAR_SERVER_ADDR :
            result = r->connection->local_ip;
            break;

        case VAR_SERVER_PORT :
            result = apr_psprintf(r->pool, "%i", (int)ap_get_server_port(r));
            break;

        case VAR_SERVER_PROTOCOL :
            result = r->protocol;
            break;

        case VAR_SERVER_SOFTWARE :
            result = ap_get_server_version();
            break;

        case VAR_API_VERSION :
            result = apr_psprintf(r->pool, "%d:%d", MODULE_MAGIC_NUMBER_MAJOR, MODULE_MAGIC_NUMBER_MINOR);
            break;

        case VAR_TIME_YEAR :
            tc = time(NULL);
            tm = localtime(&tc);
            result = apr_psprintf(r->pool, "%02d%02d", (tm->tm_year / 100) + 19, tm->tm_year % 100);
            break;

        case VAR_TIME :
            tc = time(NULL);
            tm = localtime(&tc);
            result = apr_psprintf(r->pool, "%02d%02d%02d%02d%02d%02d%02d",
                     (tm->tm_year / 100) + 19, (tm->tm_year % 100),
                     tm->tm_mon + 1, tm->tm_mday, tm->tm_hour, tm->tm_min,
                     tm->tm_sec);
            break;

        case VAR_TIME_WDAY :
            tc = time(NULL);
            tm = localtime(&tc);
            result = apr_psprintf(r->pool, "%d", tm->tm_wday);
            break;

        case VAR_TIME_SEC :
            tc = time(NULL);
            tm = localtime(&tc);
            result = apr_psprintf(r->pool, "%02d", tm->tm_sec);
            break;

        case VAR_TIME_MIN :
            tc = time(NULL);
            tm = localtime(&tc);
            result = apr_psprintf(r->pool, "%02d", tm->tm_min);
            break;

        case VAR_TIME_HOUR :
            tc = time(NULL);
            tm = localtime(&tc);
            result = apr_psprintf(r->pool, "%02d", tm->tm_hour);
            break;

        case VAR_TIME_MON :
            tc = time(NULL);
            tm = localtime(&tc);
            result = apr_psprintf(r->pool, "%02d", tm->tm_mon + 1);
            break;

        case VAR_TIME_DAY :
            tc = time(NULL);
            tm = localtime(&tc);
            result = apr_psprintf(r->pool, "%02d", tm->tm_mday);
            break;

        case VAR_SCRIPT_FILENAME :
        case VAR_REQUEST_FILENAME :
            result = r->filename;
            break;

        case VAR_PATH_INFO :
            if (msr->cache_path_info != NULL) result = msr->cache_path_info;
            else {
                result = r->path_info;
                if (result != NULL) {
                    result = normalise(r, dcfg, (char *)result, &my_error_msg);
                    msr->cache_path_info = result;
                }
            }
            break;

        case VAR_THE_REQUEST :
            if (msr->cache_the_request != NULL) result = msr->cache_the_request;
            else {
                result = r->the_request;
                if (result != NULL) {
                    result = normalise(r, dcfg, (char *)result, &my_error_msg);
                    msr->cache_the_request = result;
                }
            }
            break;

        case VAR_QUERY_STRING :
            if (msr->cache_query_string != NULL) result = msr->cache_query_string;
            else {
                result = r->args;
                if (result != NULL) {
                    result = normalise(r, dcfg, (char *)result, &my_error_msg);
                    msr->cache_query_string = result;
                }
            }
            break;

        case VAR_HANDLER :
            result = r->handler;
            break;

        case VAR_COOKIE :
            /* cookies were escaped earlier */
            result = apr_table_get(msr->parsed_cookies, v->name);
            break;

        case VAR_SCRIPT_UID :
            result = apr_psprintf(r->pool, "%i", r->finfo.user);
            break;

        case VAR_SCRIPT_GID :
            result = apr_psprintf(r->pool, "%i", r->finfo.group);
            break;

        case VAR_SCRIPT_USERNAME :
            apr_uid_name_get((char **)&result, r->finfo.user, r->pool);
            break;

        case VAR_SCRIPT_GROUPNAME :
            apr_gid_name_get((char **)&result, r->finfo.group, r->pool);
            break;

        case VAR_SCRIPT_MODE :
            result = apr_psprintf(r->pool, "%04x", r->finfo.protection);
            break;

        case VAR_HEADERS_COUNT :
            result = apr_psprintf(r->pool, "%i", sec_table_count(msr->cache_headers_in));
            break;

        case VAR_FILES_COUNT :
            if (msr->mpd != NULL) result = apr_psprintf(r->pool, "%i", multipart_contains_files(msr->mpd));
            else result = "0";
            break;

        case VAR_ARGS_COUNT :
            result = apr_psprintf(r->pool, "%i", sec_table_count(msr->parsed_args));
            break;

        case VAR_COOKIES_COUNT :
            result = apr_psprintf(r->pool, "%i", sec_table_count(msr->parsed_cookies));
            break;

        case VAR_FILE_NAME :
            if (v->name == NULL) {
                sec_debug_log(r, 1, "get_variable: Variable FILE_NAME requires name");
            } else
            if (msr->mpd != NULL) {
                multipart_part *part = multipart_get_part(msr->mpd, v->name);
                if ((part != NULL)&&(part->type == MULTIPART_FILE)&&(part->filename != NULL)) result = apr_pstrdup(r->pool, part->filename);
            }
            break;

        case VAR_FILE_SIZE :
            if (v->name == NULL) {
                sec_debug_log(r, 1, "get_variable: Variable FILE_SIZE requires name");
            } else
            if (msr->mpd != NULL) {
                multipart_part *part = multipart_get_part(msr->mpd, v->name);
                if ((part != NULL)&&(part->type == MULTIPART_FILE)&&(part->filename != NULL)) result = apr_psprintf(r->pool, "%u", part->tmp_file_size);
            }
            break;

        case VAR_REQUEST_BASENAME :
            if (msr->cache_request_basename == NULL) {
                char *p = NULL, *path = r->parsed_uri.path;
                if (path != NULL) {
                    p = strrchr(path, '/');
                    if (p != NULL) path = p + 1;
                    p = strrchr(path, '\\');
                    if (p != NULL) path = p + 1;
                    msr->cache_request_basename = normalise(r, dcfg, (char *)path, &my_error_msg);
                }
            }
            result = msr->cache_request_basename;
            break;

        case VAR_SCRIPT_BASENAME :
            if (msr->cache_script_basename == NULL) {
                char *p = NULL, *path = r->filename;
                if (path != NULL) {
                    p = strrchr(path, '/');
                    if (p != NULL) path = p + 1;
                    p = strrchr(path, '\\');
                    if (p != NULL) path = p + 1;
                    msr->cache_script_basename = normalise(r, dcfg, (char *)path, &my_error_msg);
                }
            }
            result = msr->cache_script_basename;
            break;

        default :
            sec_debug_log(r, 1, "get_variable: unresolved variable type %i (internal error)", var_type);
            break;
    }

    if (result == NULL) {
        result = "";
    }

    return result;
}

void sec_set_dir_defaults(sec_dir_config *dcfg) {
    if (dcfg == NULL) return;

    /* return immediatelly if we've already been here */
    if (dcfg->configuration_helper == 1) return;

    dcfg->configuration_helper = 1;
    if (dcfg->filter_engine == NOT_SET) dcfg->filter_engine = 0;

    if (dcfg->scan_post == NOT_SET) dcfg->scan_post = 0;
    if (dcfg->filter_debug_level == NOT_SET) dcfg->filter_debug_level = 0;
    if (dcfg->actionset == NOT_SET_P) {
        dcfg->actionset = (actionset_t *)apr_pcalloc(dcfg->p, sizeof(actionset_t));
        init_default_actionset(dcfg->actionset);
    }

    if (dcfg->auditlog_name == NOT_SET_P) dcfg->auditlog_name = NULL;
    if (dcfg->debuglog_name == NOT_SET_P) dcfg->debuglog_name = NULL;

    if (dcfg->charset_id == NOT_SET) dcfg->charset_id = UNKNOWN_CSID;
    if (dcfg->multibyte_replacement_byte == NOT_SET) dcfg->multibyte_replacement_byte = 0x0A;
}

static void *sec_create_dir_config(apr_pool_t *p, char *path) {
    sec_dir_config *dcfg = (sec_dir_config *)apr_pcalloc(p, sizeof(*dcfg));

    if (dcfg == NULL) return NULL;

    dcfg->p = p;
    dcfg->configuration_helper = NOT_SET;
    dcfg->filter_engine = NOT_SET;
    dcfg->scan_post = NOT_SET;
    dcfg->actionset = NOT_SET_P;
    dcfg->signatures = apr_array_make(p, 10, sizeof(signature *));
    dcfg->inherited_mandatory_signatures = apr_array_make(p, 10, sizeof(signature *));

    if (path == NULL) {
        dcfg->path = apr_pstrdup(p, "(null)");
    }
    else {
        dcfg->path = apr_pstrdup(p, path);
    }

    dcfg->auditlog_name = NOT_SET_P;
    dcfg->auditlog_fd = NOT_SET_P;

    dcfg->filter_debug_level = NOT_SET;
    dcfg->debuglog_name = NOT_SET_P;
    dcfg->debuglog_fd = NOT_SET_P;

    dcfg->charset_id = NOT_SET;
    dcfg->multibyte_replacement_byte = NOT_SET;

    dcfg->actionset_signatures = NOT_SET_P;

    return dcfg;
}

static void sec_merge_dir_config_inheritance(apr_pool_t *p, sec_dir_config *parent, sec_dir_config *child, sec_dir_config *new) {

    /* initialise the signature structures */
    new->signatures = apr_array_make(p, 10, sizeof(signature *));
    new->inherited_mandatory_signatures = apr_array_make(p, 10, sizeof(signature *));

    /* build a list of mandatory signatures */
    /* Note that valid values for inheritance_mandatory are -1 and 0 */
    signature **psignatures;
    int i = 0, in_chain = 0;

    /* add parent mandatory signatures to the list */
    apr_array_cat(new->inherited_mandatory_signatures, parent->inherited_mandatory_signatures);

    /* loop through parent signatures and add mandatory ones to the list */
    psignatures = (signature **)parent->signatures->elts;
    for (i = 0; i < parent->signatures->nelts; i++) {
        /* ignore placeholders and signatures that are really something else */
        if ((psignatures[i]->is_inheritance_placeholder == 0) &&
            ((in_chain)||((psignatures[i]->actionset != NULL)&&(psignatures[i]->actionset->mandatory != 0))) ) {
                *(signature **)apr_array_push(new->inherited_mandatory_signatures) = psignatures[i];
                in_chain = 0;
        }
    }

    /* inheritance should work here, so add all parent signatures */
    apr_array_cat(new->signatures, parent->signatures);

    /* processing the child context now: add proper signatures to the list, process
     * placeholders to import and remove rules where possible
     */

    {
        signature **csignatures, **nsignatures, **psignatures, **msignatures;
        int i, j, k;

        csignatures = (signature **)child->signatures->elts;
        for (i = 0; i < child->signatures->nelts; i++) {
            if (csignatures[i]->is_inheritance_placeholder != 0) {
                /* not a signature, this is a placeholder */
                if (csignatures[i]->is_inheritance_placeholder == INHERITANCE_IMPORT) {
                    signature *new_signature = NULL;
                    int is_present = 0;

                    /* import the signature from the parent context */

                    /* use the ID to find the signature in the parent context */
                    psignatures = (signature **)parent->signatures->elts;
                    for(k = 0; k < parent->signatures->nelts; k++) {
                        if ((psignatures[k]->actionset != NULL) &&
                            (psignatures[k]->actionset->id != NULL) &&
                            (strcasecmp(psignatures[k]->actionset->id, csignatures[i]->inheritance_id) == 0)) {

                            new_signature = psignatures[k];
                            break;
                        }
                    }

                    if (new_signature != NULL) {
                        /* is the signature already present in this context */
                        is_present = 0;
                        nsignatures = (signature **)new->signatures->elts;
                        for (j = 0; j < new->signatures->nelts; j++) {
                            if (new_signature == nsignatures[j]) {
                                is_present = 1;
                                break;
                            }
                        }

                        /* finally, add the signature but only if it is not already present */
                        if (is_present == 0) {
                            /* start with the signature we've just found, and include either
                             * just the signature, or all signatures that are part of the
                             * same chain
                             */
                            psignatures = (signature **)parent->signatures->elts;
                            for (j = k; j < parent->signatures->nelts; j++) {
                                /* ignore placeholders */
                                if (psignatures[j]->is_inheritance_placeholder != 0) continue;

                                *(signature **)apr_array_push(new->signatures) = psignatures[j];
                                break;
                            }
                        }
                    }

                } else {
                    /* remove signature */

                    /* find the signature in the new context */
                    nsignatures = (signature **)new->signatures->elts;
                    for (j = 0; j < new->signatures->nelts; j++) {
                        if ((nsignatures[j]->actionset != NULL) &&
                            (nsignatures[j]->actionset->id != NULL) &&
                            (strcasecmp(nsignatures[j]->actionset->id, csignatures[i]->inheritance_id) == 0)) {
                                int is_present = 0;

                                /* remove it only if it is not on the mandatory list */
                                msignatures = (signature **)new->inherited_mandatory_signatures->elts;
                                for (k = 0; k < new->inherited_mandatory_signatures->nelts; k++) {
                                    if (msignatures[k] == nsignatures[j]) {
                                        is_present = 1;
                                        break;
                                    }
                                }

                                if (is_present == 0) {
                                    signature **tsignatures = NULL;
                                    int l, pos = j, in_chain = 1;

                                    /* At this point "pos" contains the position of the
                                     * signature we wish to remove. This can be either
                                     * a standalone signature, or one that starts a
                                     * chain.
                                     */

                                    tsignatures = (signature **)new->signatures->elts;
                                    while((in_chain)&&(pos < new->signatures->nelts)) {

                                        /* determine if the signature on the current position is chained */
                                        in_chain = 0;

                                        /* remove the signature on the current position */
                                        for (l = pos; l < new->signatures->nelts - 1; l++) {
                                            tsignatures[l] = tsignatures[l + 1];
                                        }
                                        new->signatures->nelts--;
                                    }
                                }
                        }
                    }
                }
            } else {
                /* this is a normal signature so just add it do the new context */
                *(signature **)apr_array_push(new->signatures) = csignatures[i];
            }
        }
    }
}

static void *sec_merge_dir_config(apr_pool_t *p, void *_parent, void *_child) {
    sec_dir_config *parent = (sec_dir_config *)_parent;
    sec_dir_config *child = (sec_dir_config *)_child;
    sec_dir_config *new = (sec_dir_config *)apr_pcalloc(p, sizeof(*new));

    if (new == NULL) return NULL;

    /* merge the child & parent contexts into a new context */

    memcpy(new, child, sizeof(*child));

    new->filter_engine = (child->filter_engine == NOT_SET) ? parent->filter_engine : child->filter_engine;
    new->scan_post = (child->scan_post == NOT_SET) ? parent->scan_post : child->scan_post;
    new->actionset = (child->actionset == NOT_SET_P) ? parent->actionset : child->actionset;

    /* take care of signature inheritance */
    sec_merge_dir_config_inheritance(p, parent, child, new);

    if (child->auditlog_fd == NOT_SET_P) {
        new->auditlog_fd = parent->auditlog_fd;
        new->auditlog_name = parent->auditlog_name;
    }
    else {
        new->auditlog_fd = child->auditlog_fd;
        new->auditlog_name = child->auditlog_name;
    }

    new->filter_debug_level = (child->filter_debug_level == NOT_SET) ? parent->filter_debug_level : child->filter_debug_level;

    if (child->debuglog_fd == NOT_SET_P) {
        new->debuglog_fd = parent->debuglog_fd;
        new->debuglog_name = parent->debuglog_name;
    }
    else {
        new->debuglog_fd = child->debuglog_fd;
        new->debuglog_name = child->debuglog_name;
    }

    new->charset_id = (child->charset_id == NOT_SET) ? parent->charset_id : child->charset_id;
    new->multibyte_replacement_byte = (child->multibyte_replacement_byte == NOT_SET) ? parent->multibyte_replacement_byte : child->multibyte_replacement_byte;

    return new;
}

char *normalise_urlencoding_relaxed_inplace(request_rec *r, sec_dir_config *dcfg, char *uri, char **error_msg) {
    unsigned char *p_read, *p_write;
    unsigned char c;

    if (error_msg == NULL) return NULL;
    *error_msg = NULL;
    if (uri == NULL) return NULL;

    p_read = (unsigned char *)uri;
    p_write = (unsigned char *)uri;

    while ((c = *p_read) != 0) {

        if (c == '%') {

            /* see if there are enough bytes available */
            if ((*(p_read + 1) == 0)||(*(p_read + 2) == 0)) {
                c = 0;
            }
            else {
                /* here we only decode a %xx combo if it is a valid
                 * encoding, we leave it as is otherwise
                 */
                char c1 = *(p_read + 1), c2 = *(p_read + 2);

                if ( (((c1 >= '0')&&(c1 <= '9')) || ((c1 >= 'a')&&(c1 <= 'f')) || ((c1 >= 'A')&&(c1 <= 'F')))
                    && (((c2 >= '0')&&(c2 <= '9')) || ((c2 >= 'a')&&(c2 <= 'f')) || ((c2 >= 'A')&&(c2 <= 'F'))) ) {

                    c = x2c(++p_read);
                    p_read++;
                }
            }
        } else {
            /* this check is performed only against the original data
             * and not against the decoded values (we want to
             * avoid false positives)
             */
            if ((c < 0)||(c > 255)) {
                *error_msg = apr_psprintf(r->pool, "Invalid character detected [%i]", c);
                return NULL;
            }
        }

        /* replace null bytes with whitespace */
        if (c == 0) c = 32;

        *p_write++ = c;
        p_read++;
    }
    *p_write = 0;

    return uri;
}

char *normalise_urlencoding_inplace(request_rec *r, sec_dir_config *dcfg, char *uri, char **error_msg) {
    unsigned char *p_read, *p_write;
    unsigned char c;

    if (error_msg == NULL) return NULL;
    *error_msg = NULL;
    if (uri == NULL) return NULL;

    p_read = (unsigned char *)uri;
    p_write = (unsigned char *)uri;

    while ((c = *p_read) != 0) {

        /* decode URL decoding */
        if (c == '+') c = 32;
        else
        if (c == '%') {

            /* see if there are enough bytes available */
            if ((*(p_read + 1) == 0)||(*(p_read + 2) == 0)) {
                c = 0;
            }
            else {

                /* move onto the first hexadecimal letter */
                p_read++;

                c = *p_read;
                c = *(p_read + 1);

                /* decode two hexadecimal letters into a single byte */
                c = x2c(p_read);
                p_read++;
            }
        }

        if ((c < 0)||(c > 255)) {
            *error_msg = apr_psprintf(r->pool, "Invalid character detected [%i]", c);
            return NULL;
        }

        /* we replace null bytes with whitespace */
        if (c == 0) c = 32;
        *p_write++ = c;
        p_read++;
    }
    *p_write = 0;

    return uri;
}

char *normalise_other_inplace(request_rec *r, sec_dir_config *dcfg, char *uri, char **error_msg) {
    unsigned char *p_read, *p_write, *p_slash;
    unsigned char c;
    int count;

    if (error_msg == NULL) return NULL;
    *error_msg = NULL;
    if (uri == NULL) return NULL;

    p_read = (unsigned char *)uri;
    p_write = (unsigned char *)uri;
    p_slash = NULL;
    count = 0;
    while (*p_read != 0) {
        c = *p_read;

        switch (c) {

            #ifdef WIN32
            case '\\' :
            #endif

            case '/' :
                if (p_slash == NULL) {

                    /* remove the occurencies of "./" */
                    if ( (count > 1) && ((*(p_write - 1) == '.') && (*(p_write - 2) == '/')) ) {
                        count -= 2;
                        p_write -= 2;
                    }

                    p_slash = p_read;
                    *p_write++ = '/';
                    p_read++;
                    count++;
                }
                else {
                    /* the previous character was a slash, we
                     * will ignore this one - just increment
                     * the read pointer
                     */
                    p_read++;
                }
                break;

            default:
                /* p_slash is used to detect more than one
                 * slash character in a row
                 */
                p_slash = NULL;
                *p_write++ = c;
                p_read++;
                count++;

                break;
            }
    }
    *p_write = 0;

    return uri;
}

char *normalise_inplace(request_rec *r, sec_dir_config *dcfg, char *uri, char **error_msg) {
    if (error_msg == NULL) return NULL;
    *error_msg = NULL;

    if (uri == NULL) {
        *error_msg = apr_psprintf(r->pool, "null given as argument");
        return NULL;
    }

    if (normalise_urlencoding_inplace(r, dcfg, uri, error_msg) == NULL) {
        /* error_msg already populated */
        return NULL;
    }

    if (normalise_other_inplace(r, dcfg, uri, error_msg) == NULL) {
        /* error_msg already populated */
        return NULL;
    }

    return filter_multibyte_inplace(dcfg->charset_id, (char)dcfg->multibyte_replacement_byte, uri);
}

char *normalise_relaxed_inplace(request_rec *r, sec_dir_config *dcfg, char *uri, char **error_msg) {
    if (error_msg == NULL) return NULL;
    *error_msg = NULL;

    if (uri == NULL) {
        *error_msg = apr_psprintf(r->pool, "null given as argument");
        return NULL;
    }

    if (normalise_urlencoding_relaxed_inplace(r, dcfg, uri, error_msg) == NULL) {
        /* error_msg already populated */
        return NULL;
    }

    if (normalise_other_inplace(r, dcfg, uri, error_msg) == NULL) {
        /* error_msg already populated */
        return NULL;
    }

    return filter_multibyte_inplace(dcfg->charset_id, (char)dcfg->multibyte_replacement_byte, uri);
}

char *normalise_relaxed(request_rec *r, sec_dir_config *dcfg, char *_uri, char **error_msg) {
    char *uri;

    if (error_msg == NULL) return NULL;
    *error_msg = NULL;

    if (_uri == NULL) {
        *error_msg = apr_psprintf(r->pool, "null given as argument");
        return NULL;
    }
    uri = apr_pstrdup(r->pool, _uri);
    if (uri == NULL) return NULL;

    return normalise_relaxed_inplace(r, dcfg, uri, error_msg);
}

char *normalise(request_rec *r, sec_dir_config *dcfg, char *_uri, char **error_msg) {
    char *uri;

    if (_uri == NULL) return NULL;
    uri = apr_pstrdup(r->pool, _uri);
    if (uri == NULL) return NULL;

    return normalise_inplace(r, dcfg, uri, error_msg);
}

/**
 * Stores the per-request mod_security context in a place
 * (r->notes) where it will be found by other parts of
 * the code later.
 */
void store_msr(request_rec *r, modsec_rec *msr) {
    apr_table_setn(r->notes, "msr", (char *)msr);
    sec_debug_log(r, 9, "Stored msr (%x) in r (%x)", msr, r);
}

/**
 * Looks for the mod_security context for the
 * current request.
 */
modsec_rec *find_msr(request_rec *r) {
    modsec_rec *msr = NULL;
    request_rec *rx;

    msr = (modsec_rec *)apr_table_get(r->notes, "msr");
    if (msr != NULL) {
        sec_debug_log(r, 9, "Found msr (%x) in r (%x)", msr, r);
        return msr;
    }

    /* If this is a subrequest then look in the main request */
    if (r->main != NULL) {
        msr = (modsec_rec *)apr_table_get(r->main->notes, "msr");
        if (msr != NULL) {
            sec_debug_log(r, 9, "Found msr (%x) in r->main (%x)", msr, r->main);
            return msr;
        }
    }

    /* If the request was redirected then look in the previous requests */
    rx = r->prev;
    while(rx != NULL) {
        msr = (modsec_rec *)apr_table_get(rx->notes, "msr");
        if (msr != NULL) {
            sec_debug_log(r, 9, "Found msr (%x) in r->prev (%x)", msr, rx);
            return msr;
        }
        rx = rx->prev;
    }

    return NULL;
}

#define CHUNK_CAPACITY 8192

static int read_post_payload(modsec_rec *msr) {
    apr_pool_t *mptmp = NULL;
    apr_array_header_t *chunks_array = NULL;
    data_chunk *current_chunk = NULL;
    request_rec *r = msr->r;
    char *content_type, *content_length;
    char *my_error_msg = NULL;
    long len;

    msr->_post_payload = NULL;
    msr->_post_len = 0;

    if (msr->should_body_exist == 0) {
        sec_debug_log(r, 4, "read_post_payload: this request has no body (%i)", msr->should_body_exist);
        return 0;
    }

    if (msr->dcfg->scan_post != 1) {
        sec_debug_log(r, 4, "read_post_payload: request body buffering is off here (scan post = %i)", msr->dcfg->scan_post);
        return 0;
    }

    /* figure out Content-Length */
    content_length = (char *)apr_table_get(r->headers_in, "Content-Length");
    if (content_length == NULL) {
        sec_debug_log(r, 2, "read_post_payload: Content-Length not found - unable to observe request body");
        return 0;
    }

    len = strtol(content_length, NULL, 10);
    if ((len < 0)||(len + 1 <= 0)) {
        msr->tmp_message = apr_psprintf(r->pool, "Invalid Content-Length: %li", len);
        return -1;
    }

    /* msr->_post_len is unsigned long int */
    msr->_post_len = len;

    /* test for the boundary case */
    if (msr->_post_len + 1 == 0) {
        msr->tmp_message = apr_psprintf(r->pool, "Invalid Content-Length [%lu]", msr->_post_len);
        return -1;
    }

    /* Refuse to work with requests that are too large. Might prevent misconfiguration problems. */
    if (msr->_post_len >= 1073741824) {
        msr->tmp_message = apr_psprintf(r->pool, "Content-Length too long for request buffering: %lu", msr->_post_len);
        return -1;
    }

    {
    sec_filter_in_ctx *ctx = NULL;
    apr_bucket_brigade *bb;
    int seen_eos = 0;
    apr_status_t rv;

    ctx = apr_pcalloc(r->pool, sizeof(*ctx));
    if (ctx == NULL) {
        msr->_post_payload = NULL;
        msr->tmp_message = apr_psprintf(r->pool, "Unable to allocate %lu bytes", (unsigned long)sizeof(*ctx));
        return -1;
    }
    msr->ctx_in = ctx;
    ctx->type = POST_IN_MEMORY;
    ctx->tmp_file_fd = -1;
    ctx->is_multipart = 0;
    ctx->buflen = msr->_post_len;

    ctx->sofar = 0;
    ctx->done_reading = 0;
    ctx->done_writing = 0;
    ctx->output_sent = 0;
    ctx->access_check_performed = 0;

    /* PUT request bodies should always be stored on the disk,
     * because they are files, and we need to look at them,
     * optionally store them, etc.
     */
    if (r->method_number == M_PUT) {
        ctx->type = POST_ON_DISK;
        ctx->is_put = 1;
    }

    /* figure out the content-type */
    content_type = (char *)apr_table_get(r->headers_in, "Content-Type");

    /*
     * On POST requests, if the encoding is multipart/form-data and if
     * the size of the upload is greater than the maximum allowed
     * size, redirect the payload to a temporary file on disk.
     */
    if ((content_type != NULL)
        &&(r->method_number == M_POST)
        &&(strncasecmp(content_type, "multipart/form-data", 19) == 0))
    {
        ctx->is_multipart = TRUE;
        if (msr->_post_len > 65535) ctx->type = POST_ON_DISK;
    }

    /* initialize multipart handling */
    if (ctx->is_multipart) {
        msr->mpd = (multipart_data *)apr_pcalloc(r->pool, sizeof(*(msr->mpd)));
        if (msr->mpd == NULL) {
            msr->_post_payload = NULL;
            msr->tmp_message = apr_psprintf(r->pool, "Unable to allocate %lu bytes", (unsigned long)sizeof(*(msr->mpd)));
            return -1;
        }

        if (multipart_init(msr->mpd, msr, &my_error_msg) < 0) {
            msr->_post_payload = NULL;
            msr->tmp_message = apr_psprintf(r->pool, "Failed to initialise multipart/form-data parsing: %s", my_error_msg);
            return -1;
        }
    }

    if (ctx->type == POST_IN_MEMORY) {
        apr_pool_create(&mptmp, NULL);
        if (mptmp == NULL) return -1;
        ctx->sofar = 0;
        chunks_array = apr_array_make(mptmp, 64, sizeof(data_chunk *));
        if (chunks_array == NULL) return -1;
        current_chunk = (data_chunk *)apr_pcalloc(mptmp, sizeof(data_chunk));
        if (current_chunk == NULL) return -1;
        current_chunk->data = malloc(CHUNK_CAPACITY);
        if (current_chunk->data == NULL) return -1;
        current_chunk->length = 0;
        *(data_chunk **)apr_array_push(chunks_array) = current_chunk;
    }
    else {
        char *folder = NULL;

        ctx->bufleft = ctx->buflen;

        folder = get_temp_folder(r->pool);

        ctx->tmp_file_name = apr_psprintf(r->pool, "%s/%s-%s-request_body-XXXXXX", folder, current_filetime(r), r->connection->remote_ip);
        if (ctx->tmp_file_name == NULL) {
            msr->_post_payload = NULL;
            sec_debug_log(r, 1, "read_post_payload: Memory allocation failed");
            return -1;
        }

        ctx->tmp_file_fd = sec_mkstemp(ctx->tmp_file_name);
        if (ctx->tmp_file_fd < 0) {
            msr->_post_payload = NULL;
            msr->tmp_message = apr_psprintf(r->pool, "read_post_payload: Failed to create file \"%s\" because %d(\"%s\")", log_escape(r->pool, ctx->tmp_file_name), errno, log_escape(r->pool, strerror(errno)));
            return -1;
        }

        /* schedule resource cleanup for later */
        apr_pool_cleanup_register(r->pool, (void *)msr, request_body_file_cleanup, apr_pool_cleanup_null);
    }

    bb = apr_brigade_create(r->pool, r->connection->bucket_alloc);
    do {
        apr_bucket *bucket = NULL;
        rv = ap_get_brigade(r->input_filters, bb, AP_MODE_READBYTES, APR_BLOCK_READ, HUGE_STRING_LEN);
        if (rv != APR_SUCCESS) {
            msr->_post_payload = NULL;
            msr->tmp_message = apr_psprintf(r->pool, "Error reading request body, error code %i: %s", rv, get_apr_error(r->pool, rv));
            goto RP_CLEAN_ERROR_RETURN;
        }

        while(!APR_BRIGADE_EMPTY(bb)) {
            const char *data;
            apr_size_t len;

            bucket = APR_BRIGADE_FIRST(bb);

            if (APR_BUCKET_IS_EOS(bucket)) {
                seen_eos = 1;
            }
            else if (APR_BUCKET_IS_FLUSH(bucket)) {
                /* do nothing */
            }
            else {
                rv = apr_bucket_read(bucket, &data, &len, APR_BLOCK_READ);
                if (rv != APR_SUCCESS) {
                    msr->_post_payload = NULL;
                    msr->tmp_message = apr_psprintf(r->pool, "Error reading from a bucket, error code %i: %s", rv, get_apr_error(r->pool, rv));
                    goto RP_CLEAN_ERROR_RETURN;
                }

                sec_debug_log(r, 5, "read_post_payload: read %lu bytes", len);

                if (ctx->is_multipart) {
                    char *my_error_msg = NULL;

                    if (multipart_process_chunk(msr->mpd, data, len, &my_error_msg) < 0) {
                        msr->_post_payload = NULL;
                        msr->tmp_message = apr_psprintf(r->pool, "Error processing request body: %s", my_error_msg);
                        goto RP_CLEAN_ERROR_RETURN;
                    }
                }

                if (ctx->type == POST_IN_MEMORY) {
                    long int bucket_offset, bucket_left;

                    bucket_offset = 0;
                    bucket_left = len;

                    while(bucket_left > 0) {
                        if (bucket_left < (CHUNK_CAPACITY - current_chunk->length)) {
                            /* There's enough space in the current chunk. */
                            memcpy(current_chunk->data + current_chunk->length,
                                data + bucket_offset, bucket_left);
                            current_chunk->length += bucket_left;
                            bucket_left = 0;
                        } else {
                            /* Fill the existing chunk. */
                            long int copy_length = CHUNK_CAPACITY - current_chunk->length;
                            memcpy(current_chunk->data + current_chunk->length,
                                data + bucket_offset, copy_length);
                            bucket_offset += copy_length;
                            bucket_left -= copy_length;
                            current_chunk->length += copy_length;

                            /* Allocate a new chunk. */
                            current_chunk = (data_chunk *)apr_pcalloc(mptmp, sizeof(data_chunk));
                            if (current_chunk == NULL) goto RP_CLEAN_ERROR_RETURN;
                            current_chunk->data = malloc(CHUNK_CAPACITY);
                            if (current_chunk->data == NULL) goto RP_CLEAN_ERROR_RETURN;
                            current_chunk->length = 0;
                            *(data_chunk **)apr_array_push(chunks_array) = current_chunk;
                        }
                    }

                    ctx->sofar += len;
                }

                if (ctx->type == POST_ON_DISK) {
                    int i;

                    ctx->sofar += len;
                    i = write(ctx->tmp_file_fd, data, len);
                    if (i != len) {
                        msr->_post_payload = NULL;
                        msr->tmp_message = apr_psprintf(r->pool, "Error writing request body to file: %i", i);
                        if (mptmp != NULL) apr_pool_destroy(mptmp);
                        return -1;
                    }
                }

                apr_bucket_delete(bucket);
            }

            if (seen_eos) break;
        }
        apr_brigade_cleanup(bb);
    } while(!seen_eos);

    ctx->done_reading = 1;

    if (ctx->is_multipart) {
        if (multipart_complete(msr->mpd, &my_error_msg) < 0) {
            msr->tmp_message = apr_psprintf(r->pool, "Error processing request body: %s", my_error_msg);
            goto RP_CLEAN_ERROR_RETURN;
        }
    }

    if (ctx->type == POST_ON_DISK) {
        if ((ctx->tmp_file_fd != 0)&&(ctx->tmp_file_fd != -1)) {
            close(ctx->tmp_file_fd);
            ctx->tmp_file_fd = -1;
        }
    }

    if (ctx->type == POST_IN_MEMORY) {
        data_chunk **chunks = NULL;
        int i;

        /* Allocate the required amount of memory first. */
        ctx->buffer = apr_palloc(r->pool, ctx->sofar + 1);
        if ((ctx->buffer == NULL)||(ctx->sofar + 1 == 0)) {
            msr->_post_payload = NULL;
            msr->tmp_message = apr_psprintf(r->pool, "Failed to allocate %lu bytes", ctx->sofar + 1);
            goto RP_CLEAN_ERROR_RETURN;
        }

        /* Combine the data into a single buffer. */
        ctx->buflen = 0;
        chunks = (data_chunk **)chunks_array->elts;
        for(i = 0; i < chunks_array->nelts; i++) {
            if (ctx->buflen + chunks[i]->length <= ctx->sofar) {
                memcpy(ctx->buffer + ctx->buflen, chunks[i]->data, chunks[i]->length);
                ctx->buflen += chunks[i]->length;
            }
            free(chunks[i]->data);
            chunks[i]->data = NULL;
        }
        ctx->buffer[ctx->buflen] = '\0';
        ctx->output_ptr = ctx->buffer;

        apr_pool_destroy(mptmp);
        mptmp = NULL;
    }

    msr->is_body_read = 1;
    ap_add_input_filter_handle(global_sec_filter_in, ctx, r, r->connection);

    /* this is OK in all cases, ctx->buffer will
     * be NULL if the payload is not in memory
     */
    msr->_post_payload = ctx->buffer;
    msr->_post_len = ctx->buflen;
    }

    return 1;

RP_CLEAN_ERROR_RETURN:
    if (chunks_array != NULL) {
        data_chunk **chunks = NULL;
        int i;

        chunks = (data_chunk **)chunks_array->elts;
        for(i = 0; i < chunks_array->nelts; i++) {
            if (chunks[i]->data != NULL) {
                free((void *)chunks[i]->data);
            }
        }
    }
    if (mptmp != NULL) apr_pool_destroy(mptmp);
    return -1;
}

int parse_arguments(char *s, apr_table_t *parsed_args, request_rec *r, sec_dir_config *dcfg, char **error_msg) {
    long inputlength, i, j;
    char *my_error_msg = NULL;
    char *value = NULL;
    char *buf;
    int status;

    if (error_msg == NULL) return -1;
    *error_msg = NULL;

    if (s == NULL) return -1;
    inputlength = strlen(s);
    if (inputlength == 0) return 1;
    if (inputlength + 1 <= 0) return -1;

    buf = (char *)malloc(inputlength + 1);
    if (buf == NULL) {
        *error_msg = apr_psprintf(r->pool, "Failed to allocate %li bytes", inputlength + 1);
        return -1;
    }

    i = 0;
    j = 0;
    status = 0;
    while (i < inputlength) {
        if (status == 0) {
            /* parameter name */
            while ((s[i] != '=') && (s[i] != '&') && (i < inputlength)) {
                buf[j] = s[i];
                j++;
                i++;
            }
            buf[j++] = 0;
        } else {
            /* parameter value */
            while ((s[i] != '&') && (i < inputlength)) {
                buf[j] = s[i];
                j++;
                i++;
            }
            buf[j++] = 0;
        }

        if (status == 0) {
            if (normalise_inplace(r, dcfg, buf, &my_error_msg) == NULL) {
                free(buf);
                *error_msg = apr_psprintf(r->pool, "Error normalising parameter name: %s", my_error_msg);
                return -1;
            }

            if (s[i] == '&') {
                /* Empty parameter */
                sec_debug_log(r, 4, "Adding parameter: \"%s\" (empty)", log_escape(r->pool, buf));
                apr_table_add(parsed_args, buf, "");
                status = 0; /* unchanged */
                j = 0;
            } else {
                status = 1;
                value = &buf[j];
            }
        }
        else {
            if (normalise_inplace(r, dcfg, value, &my_error_msg) == NULL) {
                free(buf);
                *error_msg = apr_psprintf(r->pool, "Error normalising parameter value: %s", my_error_msg);
                return -1;
            }
            sec_debug_log(r, 4, "Adding parameter: \"%s\"=\"%s\"", log_escape(r->pool, buf), log_escape(r->pool, value));
            apr_table_add(parsed_args, buf, value);
            status = 0;
            j = 0;
        }

        i++; /* skip over the separator */
    }

    /* last parameter was empty */
    if (status == 1) {
        sec_debug_log(r, 4, "Adding parameter: \"%s\" (empty)", log_escape(r->pool, buf));
        apr_table_add(parsed_args, buf, "");
    }

    free(buf);
    return 1;
}

char *remove_binary_content(request_rec *r, char *data, long size) {
    char *src, *dst, *newdata;

    if (data == NULL) return NULL;
    if ((size < 0)||(size + 1 <= 0)) return NULL;

    /* make a copy of the payload first */
    newdata = apr_palloc(r->pool, size + 1);
    if (newdata == NULL) {
        sec_debug_log(r, 1, "remove_binary_content: failed to allocate %li bytes", size + 1);
        return NULL;
    }

    /* remove zeros from the payload */
    src = data;
    dst = newdata;
    while(size--) {
        if (*src != 0) *dst++ = *src++;
        else src++;
    }
    *dst = 0;

    return newdata;
}

int check_single_signature(modsec_rec *msr, signature *sig) {
    char *my_error_msg;

    int rc = _check_single_signature(msr, sig, &my_error_msg);
    if (rc == DECLINED) {
        msr->tmp_message = apr_psprintf(msr->r->pool, "Error processing signature: %s", my_error_msg);
        return perform_action(msr, msr->dcfg->actionset, sig);
    }
    return rc;
}

int _check_single_signature(modsec_rec *msr, signature *sig, char **error_msg) {
    int j, rs;

    if (error_msg == NULL) return HTTP_INTERNAL_SERVER_ERROR;
    *error_msg = NULL;

    /*
     * the idea behind non-selective filters is to apply them over
     * raw data, typically the complete first line of the request
     * and the complete POST payload
     */

    if (sig->is_selective == 0) {
        sec_debug_log(msr->r, 2, "Checking signature \"%s\" at REQUEST_URI", log_escape(msr->r->pool, sig->pattern));

        rs = check_sig_against_string(msr, sig, msr->request_uri, VAR_REQUEST_URI, NULL);
        if (rs != OK) return rs;

        if (msr->is_body_read) {
            if (msr->mpd != NULL) {
                /* multipart/form-data request */
                if (msr->_fake_post_payload == NULL) {
                    msr->_fake_post_payload = construct_fake_urlencoded(msr, msr->parsed_args);
                    if (msr->_fake_post_payload == NULL) {
                        *error_msg = apr_psprintf(msr->r->pool, "Failed during fake POST payload construction");
                        return DECLINED;
                    }
                }
                sec_debug_log(msr->r, 2, "Checking signature \"%s\" at POST_PAYLOAD (faked)", log_escape(msr->r->pool, sig->pattern));
                rs = check_sig_against_string(msr, sig, msr->_fake_post_payload, VAR_POST_PAYLOAD, NULL);
                if (rs != OK) return rs;
            } else {
                if (msr->_post_payload != NULL) {
                    sec_debug_log(msr->r, 2, "Checking signature \"%s\" at POST_PAYLOAD", log_escape(msr->r->pool, sig->pattern));
                    rs = check_sig_against_string(msr, sig, msr->_post_payload, VAR_POST_PAYLOAD, NULL);
                    if (rs != OK) return rs;
                }
            }
        }
    }
    else {
        variable **variables;
        const char *v;

        /* this is a selective signature, this means that we need to
         * check only one part of the request and leave the rest alone
         */

        /* selective signatures can be negative and non-negative;
         * non-negative signatures consist of a list of variables
         * that represent parts of the request that need to be
         * checked; negative signatures apply only to request
         * arguments, when you want to exclude an argument from
         * a check
         */

        if (sig->is_negative == 0) {

            /* loop through signature variables and
             * check them
             */

            variables = (variable **)sig->variables->elts;
            for (j = 0; j < sig->variables->nelts; j++) {

                if (variables[j]->type == VAR_ARGS) {
                    sec_debug_log(msr->r, 2, "Checking signature \"%s\" at QUERY_STRING", log_escape(msr->r->pool, sig->pattern));

                    v = get_variable(msr, variables[j], VAR_QUERY_STRING);

                    rs = check_sig_against_string(msr, sig, v, VAR_QUERY_STRING, NULL);
                    if (rs != OK) return rs;

                    if (msr->is_body_read) {
                        if (msr->mpd != NULL) {
                            /* multipart/form-data request */
                            if (msr->_fake_post_payload == NULL) {
                                msr->_fake_post_payload = construct_fake_urlencoded(msr, msr->parsed_args);
                                if (msr->_fake_post_payload == NULL) {
                                    *error_msg = apr_psprintf(msr->r->pool, "Failed during fake POST payload construction");
                                    return DECLINED;
                                }
                            }
                            sec_debug_log(msr->r, 2, "Checking signature \"%s\" at POST_PAYLOAD (faked)", log_escape(msr->r->pool, sig->pattern));
                            rs = check_sig_against_string(msr, sig, msr->_fake_post_payload, VAR_POST_PAYLOAD, NULL);
                            if (rs != OK) return rs;
                        } else {
                            if (msr->_post_payload != NULL) {
                                sec_debug_log(msr->r, 2, "Checking signature \"%s\" at POST_PAYLOAD", log_escape(msr->r->pool, sig->pattern));
                                rs = check_sig_against_string(msr, sig, msr->_post_payload, VAR_POST_PAYLOAD, NULL);
                                if (rs != OK) return rs;
                            }
                        }
                    }
                }
                else if (variables[j]->type == VAR_POST_PAYLOAD) {
                    /* Ignore requests without bodies */
                    if (msr->should_body_exist) {
                        /* Note it can happen that a body is available but
                         * _post_payload is NULL.
                         */
                        if (msr->is_body_read == 0) {
                            /* Only complain if body is not available by configuration mistake */
                            return OK;
                        } else {
                            if (msr->mpd == NULL) {
                                if (msr->_post_payload != NULL) {
                                    sec_debug_log(msr->r, 2, "Checking signature \"%s\" at POST_PAYLOAD", log_escape(msr->r->pool, sig->pattern));
                                    rs = check_sig_against_string(msr, sig, msr->_post_payload, VAR_POST_PAYLOAD, NULL);
                                    if (rs != OK) return rs;
                                }
                            } else {
                                /* multipart/form-data request */
                                if (msr->_fake_post_payload == NULL) {
                                    msr->_fake_post_payload = construct_fake_urlencoded(msr, msr->parsed_args);
                                    if (msr->_fake_post_payload == NULL) {
                                        *error_msg = apr_psprintf(msr->r->pool, "Failed during fake POST payload construction");
                                        return DECLINED;
                                    }
                                }
                                sec_debug_log(msr->r, 2, "Checking signature \"%s\" at POST_PAYLOAD (faked)", log_escape(msr->r->pool, sig->pattern));
                                rs = check_sig_against_string(msr, sig, msr->_fake_post_payload, VAR_POST_PAYLOAD, NULL);
                                if (rs != OK) return rs;
                            }
                        }
                    }
                }
                else if (variables[j]->type == VAR_ARGS_NAMES) {
                    apr_table_entry_t *te;
                    const apr_array_header_t *arr;
                    int k;

                    sec_debug_log(msr->r, 2, "Checking signature \"%s\" at ARGS_NAMES", log_escape(msr->r->pool, sig->pattern));

                    arr = apr_table_elts(msr->parsed_args);
                    te = (apr_table_entry_t *)arr->elts;
                    for (k = 0; k < arr->nelts; k++) {
                        rs = check_sig_against_string(msr, sig, te[k].key, VAR_ARGS_NAMES, NULL);
                        if (rs != OK) return rs;
                    }
                }
                else if (variables[j]->type == VAR_ARGS_VALUES) {
                    apr_table_entry_t *te;
                    const apr_array_header_t *arr;
                    int k;

                    sec_debug_log(msr->r, 2, "Checking signature \"%s\" at ARGS_VALUES", log_escape(msr->r->pool, sig->pattern));

                    arr = apr_table_elts(msr->parsed_args);
                    te = (apr_table_entry_t *)arr->elts;
                    for (k = 0; k < arr->nelts; k++) {
                        sec_debug_log(msr->r, 4, "Checking signature \"%s\" at ARGS_VALUES(\"%s\")", log_escape(msr->r->pool, sig->pattern), log_escape(msr->r->pool, te[k].key));
                        rs = check_sig_against_string(msr, sig, te[k].val, VAR_ARGS_VALUES, te[k].key);
                        if (rs != OK) return rs;
                    }
                }
                else if (variables[j]->type == VAR_COOKIES_NAMES) {
                    apr_table_entry_t *te;
                    const apr_array_header_t *arr;
                    int k;

                    sec_debug_log(msr->r, 2, "Checking signature \"%s\" at COOKIES_NAMES", log_escape(msr->r->pool, sig->pattern));

                    arr = apr_table_elts(msr->parsed_cookies);
                    te = (apr_table_entry_t *)arr->elts;
                    for (k = 0; k < arr->nelts; k++) {
                        /*sec_debug_log(msr->r, 5, "Cookie \"%s\"="%s\"", log_escape(msr->r->pool, te[k].key), log_escape(msr->r->pool, te[k].val));*/
                        rs = check_sig_against_string(msr, sig, te[k].key, VAR_COOKIES_NAMES, NULL);
                        if (rs != OK) return rs;
                    }
                }
                else if (variables[j]->type == VAR_COOKIES_VALUES) {
                    apr_table_entry_t *te;
                    const apr_array_header_t *arr;
                    int k;

                    sec_debug_log(msr->r, 2, "Checking signature \"%s\" at COOKIES_VALUES", log_escape(msr->r->pool, sig->pattern));

                    arr = apr_table_elts(msr->parsed_cookies);
                    te = (apr_table_entry_t *)arr->elts;
                    for (k = 0; k < arr->nelts; k++) {
                        sec_debug_log(msr->r, 4, "Checking signature \"%s\" at COOKIES_VALUES(\"%s\")", log_escape(msr->r->pool, sig->pattern), log_escape(msr->r->pool, te[k].key));
                        rs = check_sig_against_string(msr, sig, te[k].val, VAR_COOKIES_VALUES, te[k].key);
                        if (rs != OK) return rs;
                    }
                }
                else if (variables[j]->type == VAR_HEADERS) {
                    apr_table_entry_t *te;
                    const apr_array_header_t *arr;
                    int k;

                    sec_debug_log(msr->r, 2, "Checking signature \"%s\" at HEADERS", log_escape(msr->r->pool, sig->pattern));

                    arr = apr_table_elts(msr->cache_headers_in);
                    te = (apr_table_entry_t *)arr->elts;
                    for (k = 0; k < arr->nelts; k++) {
                        char *header_value = apr_psprintf(msr->r->pool, "%s: %s", te[k].key, te[k].val);
                        rs = check_sig_against_string(msr, sig, header_value, VAR_HEADERS, NULL);
                        if (rs != OK) return rs;
                    }
                }
                else if (variables[j]->type == VAR_HEADERS_NAMES) {
                    apr_table_entry_t *te;
                    const apr_array_header_t *arr;
                    int k;

                    sec_debug_log(msr->r, 2, "Checking signature \"%s\" at HEADERS_NAMES", log_escape(msr->r->pool, sig->pattern));

                    arr = apr_table_elts(msr->cache_headers_in);
                    te = (apr_table_entry_t *)arr->elts;
                    for (k = 0; k < arr->nelts; k++) {
                        rs = check_sig_against_string(msr, sig, te[k].key, VAR_HEADERS_NAMES, NULL);
                        if (rs != OK) return rs;
                    }
                }
                else if (variables[j]->type == VAR_HEADERS_VALUES) {
                    apr_table_entry_t *te;
                    const apr_array_header_t *arr;
                    int k;

                    sec_debug_log(msr->r, 2, "Checking signature \"%s\" at HEADERS_VALUES", log_escape(msr->r->pool, sig->pattern));

                    arr = apr_table_elts(msr->cache_headers_in);
                    te = (apr_table_entry_t *)arr->elts;
                    for (k = 0; k < arr->nelts; k++) {
                        sec_debug_log(msr->r, 4, "Checking signature \"%s\" at HEADERS_VALUES(\"%s\")", log_escape(msr->r->pool, sig->pattern), log_escape(msr->r->pool, te[k].key));
                        rs = check_sig_against_string(msr, sig, te[k].val, VAR_HEADERS_VALUES, te[k].key);
                        if (rs != OK) return rs;
                    }
                }
                else if (variables[j]->type == VAR_FILES_NAMES) {
                    sec_debug_log(msr->r, 2, "Checking signature \"%s\" at FILES_NAMES", log_escape(msr->r->pool, sig->pattern));
                    if (msr->mpd != NULL) {
                        rs = multipart_check_files_names(msr, sig, variables[j]);
                        if (rs != OK) return rs;
                    }
                }
                else if (variables[j]->type == VAR_FILES_SIZES) {
                    sec_debug_log(msr->r, 2, "Checking signature \"%s\" at FILES_SIZES", log_escape(msr->r->pool, sig->pattern));
                    if (msr->mpd != NULL) {
                        rs = multipart_check_files_sizes(msr, sig, variables[j]);
                        if (rs != OK) return rs;
                    }
                }
                else if (variables[j]->type == VAR_COOKIE) {
                    apr_table_entry_t *te;
                    const apr_array_header_t *arr;
                    int k, count = 0;

                    count = 0;
                    arr = apr_table_elts(msr->parsed_cookies);
                    te = (apr_table_entry_t *)arr->elts;
                    for (k = 0; k < arr->nelts; k++) {
                        if (strcasecmp(te[k].key, variables[j]->name) == 0) {
                            count++;
                            sec_debug_log(msr->r, 2, "Checking signature \"%s\" at COOKIE(\"%s\")", log_escape(msr->r->pool, sig->pattern), variables[j]->name);
                            rs = check_sig_against_string(msr, sig, te[k].val, VAR_COOKIE, te[k].key);
                            if (rs != OK) return rs;

                        }
                    }

                    /* If the named cookie does not exist make a check
                     * treating it as it were present but empty.
                     */
                    if (count == 0) {
                        sec_debug_log(msr->r, 2, "Checking signature \"%s\" at COOKIE(\"%s\")", log_escape(msr->r->pool, sig->pattern), variables[j]->name);
                        rs = check_sig_against_string(msr, sig, "", VAR_COOKIE, variables[j]->name);
                        if (rs != OK) return rs;
                    }
                }
                else if (variables[j]->type == VAR_ARG) {
                    apr_table_entry_t *te;
                    const apr_array_header_t *arr;
                    int k, count = 0;

                    count = 0;
                    arr = apr_table_elts(msr->parsed_args);
                    te = (apr_table_entry_t *)arr->elts;
                    for (k = 0; k < arr->nelts; k++) {
                        if (strcasecmp(te[k].key, variables[j]->name) == 0) {
                            count++;
                            sec_debug_log(msr->r, 2, "Checking signature \"%s\" at ARG(\"%s\")", log_escape(msr->r->pool, sig->pattern), variables[j]->name);
                            rs = check_sig_against_string(msr, sig, te[k].val, VAR_ARG, te[k].key);
                            if (rs != OK) return rs;
                        }
                    }

                    /* If the named parameter does not exist make a check
                     * treating it as it were present but empty
                     */
                    if (count == 0) {
                        sec_debug_log(msr->r, 2, "Checking signature \"%s\" at ARG(\"%s\")", log_escape(msr->r->pool, sig->pattern), variables[j]->name);
                        rs = check_sig_against_string(msr, sig, "", VAR_ARG, variables[j]->name);
                        if (rs != OK) return rs;
                    }
                }
                else {
                    /* simple variable, get the value and check it */
                    char *where = NULL;

                    if (variables[j]->name == NULL) where = apr_psprintf(msr->r->pool, "%s", all_variables[variables[j]->type]);
                    else where = apr_psprintf(msr->r->pool, "%s(%s)", all_variables[variables[j]->type], variables[j]->name);

                    v = get_variable(msr, variables[j], variables[j]->type);
                    if (v != NULL) {
                        sec_debug_log(msr->r, 2, "Checking signature \"%s\" at %s", log_escape(msr->r->pool, sig->pattern), where);
                        rs = check_sig_against_string(msr, sig, (char *)v, variables[j]->type, variables[j]->name);
                        if (rs != OK) return rs;
                    }
                    else {
                        sec_debug_log(msr->r, 1, "Variable not found \"%s\"", log_escape(msr->r->pool, where));
                    }
                }
            }
        }
        else {
            apr_table_t *our_parsed_args;
            char *fake_body = NULL;

            our_parsed_args = apr_table_copy(msr->r->pool, msr->parsed_args);

            /* Find the unwanted variable names in the signature
             * data and remove them from the variable list.
             */
            variables = (variable **)sig->variables->elts;
            for (j = 0; j < sig->variables->nelts; j++) {
                if ((variables[j]->type == VAR_ARG) && (variables[j]->action == VAR_ACTION_ALLOW)) {
                    apr_table_unset(our_parsed_args, variables[j]->name);
                }
            }

            fake_body = construct_fake_urlencoded(msr, our_parsed_args);
            if (fake_body == NULL) {
                *error_msg = apr_psprintf(msr->r->pool, "Failed with construct_fake_urlencoded");
                return DECLINED;
            }

            /* make the check against the compiled string */
            sec_debug_log(msr->r, 2, "Checking signature \"%s\" at ARGS_SELECTIVE", log_escape(msr->r->pool, sig->pattern));
            rs = check_sig_against_string(msr, sig, (char *)fake_body, VAR_ARGS_SELECTIVE, NULL);
            if (rs != OK) return rs;
        }
    }

    return OK;
}

int sec_check_all_signatures(modsec_rec *msr) {
    request_rec *r = msr->r;
    signature **signatures;
    int i;
    int mode = 0;
    int skip_count = 0;
    int rc = DECLINED;

    /* loop through all signatures */
    signatures = (signature **)msr->dcfg->signatures->elts;
    for (i = 0; i < msr->dcfg->signatures->nelts; i++) {

        /* do not process signatures that are not proper signatures */
        if (signatures[i]->is_inheritance_placeholder != 0) continue;

        /* output rules are not processed here */
        if (signatures[i]->is_output != PHASE_INPUT) continue;

        /* check if we need to skip this rule */
        if (skip_count > 0) {
            skip_count--;
            continue;
        }

        /* just clear the flag, we had to use the flag
         * to detect a case when the last rule in the
         * rule chain was marked as chained
         */
        if (mode == 2) mode = 0;

        /* in mode 1, we are looking for the next filter,
         * next chained that is, and then skip it to
         * execute the next filter in the chain
         */
        if (mode == 1) {
            mode = 0;
            continue;
        }

        msr->tmp_message = NULL;

        rc = check_single_signature(msr, signatures[i]);
        sec_debug_log(r, 9, "Signature check returned %i", rc);

        /* MODSEC_ALLOW means that an allow action was called,
         * we need to pass the request through
         */
        if (rc == MODSEC_ALLOW) {
            sec_debug_log(r, 9, "Allow request to pass through");
            return DECLINED;
        }

        /* OK means there was no filter match, we
         * switch to mode 1, processing will continue
         * with the next filter chain
         */
        if (rc == OK) {
            continue;
        }

        /* any status greater than zero means there
         * was a filter match, so we either stop execution
         * or proceed to the next rule if this rule was
         * chained
         */
        if (rc > 0) {
rule_match:
            sec_debug_log(r, 9, "Rule match, returning code %i", rc);
            return rc;
        }

        /* if the return status is zero this
         * means skip some rules, so we skip
         */
        if (rc == MODSEC_SKIP) {
            if (signatures[i]->actionset == NULL) skip_count = 1;
            else skip_count = signatures[i]->actionset->skip_count;
            continue;
        }

        sec_debug_log(r, 1, "Unprocessed return code %i", rc);
        return DECLINED;
    }

    /* handle the case where there was a match on the
     * last filter so mode 2 check could not be done
     * strickly speaking this should be a configuration error
     */
    if (mode == 2) {
        sec_debug_log(r, 1, "Last rule marked as chained - ignoring");
        goto rule_match;
    }

    return DECLINED;
}

int check_sig_against_string(modsec_rec *msr, signature *_sig, const char *s, int var_type, char *var_name) {
    request_rec *r = msr->r;
    apr_time_t time_before_regex;
    int regex_result = 0;
    int rc = OK;

    if (_sig->regex == NULL) {
        msr->tmp_message = apr_psprintf(r->pool, "Compiled regex for pattern \"%s\" is null!", log_escape(r->pool, _sig->pattern));
        return perform_action(msr, msr->dcfg->actionset, _sig);
    }

    if (s == NULL) {
        msr->tmp_message = apr_psprintf(r->pool, "check_sig_against_sig: Internal Error: received null for argument");
        return perform_action(msr, msr->dcfg->actionset, _sig);;
    }

    sec_debug_log(r, 4, "Checking against \"%s\"", log_escape(r->pool, (char *)s));

    time_before_regex = apr_time_now();
    regex_result = ap_regexec(_sig->regex, s, 0, NULL, 0);
    sec_debug_log(r, 9, "Check took %u usec", (apr_time_now() - time_before_regex));

    if ( ((regex_result == 0)&&(_sig->is_allow == 0)) || ((regex_result != 0)&&(_sig->is_allow == 1)) ) {
        if (var_name == NULL) msr->tmp_message = apr_psprintf(msr->r->pool, "Pattern match \"%s\" at %s", log_escape(r->pool, _sig->pattern), all_variables[var_type]);
        else msr->tmp_message = apr_psprintf(msr->r->pool, "Pattern match \"%s\" at %s(\"%s\")", log_escape(r->pool, _sig->pattern), all_variables[var_type], log_escape(r->pool, var_name));
        rc = perform_action(msr, msr->dcfg->actionset, _sig);
    }

    return rc;
}

static char *create_per_rule_actionset(cmd_parms *cmd, sec_dir_config *dcfg, signature *sig, char *config, actionset_t *actionset) {
    init_empty_actionset(actionset);

    if (config == NULL) {
        return NULL;
    }

    /* the id and msg actions can only be used on a rule that is
     * starting a chain, or on a standalone rule
     */
    if ((actionset->mandatory)||(actionset->id != NULL)
        ||(actionset->rev != NULL)
    ) {
        signature **signatures = NULL, *previous_signature = NULL;
        int i;

        /* go back, ignoring placeholders, and look for the rule before this one */

        signatures = (signature **)dcfg->signatures->elts;
        for (i = dcfg->signatures->nelts - 1; i >= 0; i--) {
            if (signatures[i]->is_inheritance_placeholder != 0) continue;
            previous_signature = signatures[i];
            break;
        }
    }

    return NULL;
}

static const char *cmd_audit_log(cmd_parms *cmd, void *in_dcfg, const char *p1) {
    sec_dir_config *dcfg = in_dcfg;

    dcfg->auditlog_name = (char *)p1;

    if (dcfg->auditlog_name[0] == '|') {
        const char *pipe_name = ap_server_root_relative(cmd->pool, dcfg->auditlog_name + 1);
        piped_log *pipe_log;

        pipe_log = ap_open_piped_log(cmd->pool, pipe_name);
        if (pipe_log == NULL) {
            return apr_psprintf(cmd->pool, "mod_log_post: Failed to open the post log pipe: %s", pipe_name);
        }
        dcfg->auditlog_fd = ap_piped_log_write_fd(pipe_log);
    }
    else {
        const char *file_name = ap_server_root_relative(cmd->pool, dcfg->auditlog_name);
        apr_status_t rc;

        rc = apr_file_open(&dcfg->auditlog_fd, file_name,
            APR_WRITE | APR_APPEND | APR_CREATE | APR_BINARY,
            CREATEMODE, cmd->pool);

        if (rc != APR_SUCCESS) {
            return apr_psprintf(cmd->pool, "mod_log_post: Failed to open the post log file: %s", file_name);
        }
    }

    return NULL;
}

static const char *cmd_scan_post(cmd_parms *cmd, void *in_dcfg, int flag) {
    sec_dir_config *dcfg = in_dcfg;

    dcfg->filter_engine = flag;
    dcfg->scan_post = flag;

    signature *sig;
    const char *p3 = "log,pass";

    /* initialise the structure first */
    sig = apr_pcalloc(cmd->pool, sizeof(signature));
    if (sig == NULL) return FATAL_ERROR;

    sig->is_allow = 0;
    sig->is_selective = 1;
    sig->is_negative = 0;
    sig->requires_parsed_args = 0;
    sig->actionset = NULL;
    sig->variables = apr_array_make(cmd->pool, 10, sizeof (variable *));

    sig->pattern = "POST";
    sig->regex = ap_pregcomp(cmd->pool, "POST", REG_ICASE | REG_NOSUB);

    if (sig->regex == NULL) {
        return apr_psprintf(cmd->pool, "Invalid regular expression: %s", sig->pattern);
    }

    /* add the token to the list */
    variable *v = (variable *)apr_pcalloc(cmd->pool, sizeof(variable));
    if (v == NULL) return FATAL_ERROR;
    v->name = NULL;
    v->action = VAR_ACTION_DENY;
    v->type = VAR_REQUEST_METHOD;

    if ((v->type == VAR_ARGS_NAMES)||(v->type == VAR_ARGS_VALUES)) sig->requires_parsed_args = 1;

    *(variable **)apr_array_push(sig->variables) = v;

    actionset_t *signature_actionset = NULL;
    char *error_message = NULL;

    signature_actionset = (actionset_t *)apr_pcalloc(cmd->pool, sizeof(actionset_t));
    if (dcfg->actionset_signatures != NOT_SET_P) {
        error_message = create_per_rule_actionset(cmd, dcfg, sig, (char *)p3, signature_actionset);
        if (error_message != NULL) return error_message;
        sig->actionset = merge_actionsets(cmd->pool, dcfg->actionset_signatures, signature_actionset);
        if (sig->actionset == NULL) return "Failed to merge actionsets";
    } else {
        actionset_t temporary_actionset;

        init_default_actionset(&temporary_actionset);

        error_message = create_per_rule_actionset(cmd, dcfg, sig, (char *)p3, signature_actionset);
        if (error_message != NULL) return error_message;
        sig->actionset = merge_actionsets(cmd->pool, &temporary_actionset, signature_actionset);
        if (sig->actionset == NULL) return "Failed to merge actionsets";
    }

    /* add the signature to the list of all signatures */
    *(signature **)apr_array_push(dcfg->signatures) = sig;

    return NULL;
}

static const char *cmd_filter_debug_log(cmd_parms *cmd, void *in_dcfg, const char *p1) {
    sec_dir_config *dcfg = in_dcfg;
    int rc;

    dcfg->debuglog_name = ap_server_root_relative(cmd->pool, p1);

    rc = apr_file_open(&dcfg->debuglog_fd, dcfg->debuglog_name,
                   APR_WRITE | APR_APPEND | APR_CREATE | APR_BINARY,
                   CREATEMODE, cmd->pool);

    if (rc != APR_SUCCESS) {
        return apr_psprintf(cmd->pool, "mod_log_post: Failed to open the debug log file: %s", dcfg->debuglog_name);
    }

    return NULL;
}

static const char *cmd_filter_debug_level(cmd_parms *cmd, void *in_dcfg, const char *p1) {
    sec_dir_config *dcfg = in_dcfg;
    dcfg->filter_debug_level = atoi(p1);
    return NULL;
}

static const command_rec sec_cmds[] = {
     AP_INIT_FLAG (
         "PostLogging",
         cmd_scan_post,
         NULL,
         RSRC_CONF | ACCESS_CONF,
         "On or Off to trigger HTTP POST message logging"
     ),

     AP_INIT_TAKE1 (
         "PostLogFile",
         cmd_audit_log,
         NULL,
         RSRC_CONF | ACCESS_CONF,
         "The filename of the HTTP POST message log file"
     ),

     AP_INIT_TAKE1 (
         "PostLogDebugFile",
         cmd_filter_debug_log,
         NULL,
         RSRC_CONF | ACCESS_CONF,
         "The filename where debug output will be written to"
     ),

     AP_INIT_TAKE1 (
         "PostLogDebugLevel",
         cmd_filter_debug_level,
         NULL,
         RSRC_CONF | ACCESS_CONF,
         "The level of the debugging log file verbosity"
     ),

     { NULL }
};


/* -- Log functions (PLOGGING) --------------------------------------------- */

/**
 * This function is the main entry point for logging.
 */
static int sec_logger(request_rec *r) {
    const apr_array_header_t *arr = NULL;
    request_rec *origr = NULL;
    modsec_rec *msr = NULL;

    sec_debug_log(r, 2, "Logging phase starting");

    /* -- Initialise logging -- */

    /* Find the first (origr) and the last (r) request */
    origr = r;
    while(origr->prev) {
        origr = origr->prev;
    }
    while(r->next) {
        r = r->next;
    }

    /* At this point r is the last request in the
     * chain. However, we now need to detect a case when
     * a bad ErrorDocument was used and back out of it. That's
     * how Apache does it internally. Except where Apache knows
     * exactly what is happening we will have to rely on the missing
     * headers in the final request to detect this condition.
     */
    arr = apr_table_elts(r->headers_out);
    while ((arr->nelts == 0)&&(r->prev != NULL)) {
        r = r->prev;
        arr = apr_table_elts(r->headers_out);
    }

    /* Find the main context */
    msr = find_msr(r);

    /* msr may be null in cases where Apache encountered an
     * invalid request. Such requests will not go through all
     * processing stages, but will go through the logging phase.
     */
    if (msr == NULL) {
        msr = sec_create_context(origr);
    }
    if (msr->dcfg == NULL) return DECLINED;


    /* -- Audit logging starts here -- */

    /* Do not log anything if we were specifically asked not to */
    if (msr->explicit_auditlog == 0) {
        sec_debug_log(r, 4, "Audit log: Not logging because asked not to");
        return DECLINED;
    }

    /* We are processing the switch statement only if we
     * are not aware about any explicit instructions about
     * audit logging. The explicit instructions always
     * override the configuration settings.
     */
    if (msr->explicit_auditlog == NOT_SET) {
        if ((r->handler != NULL)||(origr->handler != NULL)) msr->is_dynamic = 1;
        else msr->is_dynamic = 0;

        if (msr->is_relevant == 0) {
            sec_debug_log(r, 3, "Audit log: Set to RelevantOnly - ignoring a non-relevant request");
            return DECLINED;
        }
    }

    sec_auditlog_init(msr);

    /* return immediatelly if we don't have a file to write to */
    if ((msr->dcfg->auditlog_fd == NULL)||(msr->dcfg->auditlog_fd == NOT_SET_P)) {
        sec_debug_log(r, 1, "Audit log enabled, but filename not specified, uri=\"%s\"", log_escape(r->pool, r->uri));
        return DECLINED;
    }

    sec_audit_logger_serial(r, origr, msr->dcfg, msr);

    /* -- Done logging -- */

    /* It doesn't matter what we return, Apache will
     * execute all handlers registered with the logging
     * hook.
     */
    return DECLINED;
}

/**
 * Construct a log line in the vcombinedus format (see below).
 */
static char *construct_log_vcombinedus(request_rec *r, request_rec *origr) {
    char *local_user, *remote_user;
    char *referer, *user_agent, *uniqueid;
    char *sessionid = "-"; /* not used yet */

    /* remote log name */
    if (r->connection->remote_logname == NULL) remote_user = "-";
    else remote_user = r->connection->remote_logname;

    /* authenticated user */
    if (r->user == NULL) local_user = "-";
    else local_user = r->user;

    /* unique id */
    uniqueid = (char *)get_env_var(r, "UNIQUE_ID");
    if (uniqueid == NULL) uniqueid = "-";

    /* referer */
    referer = (char *)apr_table_get(r->headers_in, "Referer");
    if (referer == NULL) referer = "-";

    /* user agent */
    user_agent = (char *)apr_table_get(r->headers_in, "User-Agent");
    if (user_agent == NULL) user_agent = "-";

    return apr_psprintf(r->pool, "%s %s %s %s [%s] \"%s\" %i %" APR_OFF_T_FMT " \"%s\" \"%s\" %s \"%s\"",
        ap_get_server_name(r), r->connection->remote_ip, log_escape(r->pool, remote_user),
        log_escape(r->pool, local_user), current_logtime(r),
        ((origr->the_request == NULL) ? "" : log_escape(r->pool, origr->the_request)),
        origr->status, r->bytes_sent, log_escape(r->pool, referer), log_escape(r->pool, user_agent),
        log_escape(r->pool, uniqueid), sessionid);
}

const char *get_response_protocol(request_rec *r) {
    int proto_num = r->proto_num;

    if (r->assbackwards) {
        return NULL;
    }

    if (proto_num > HTTP_VERSION(1,0)
        && apr_table_get(r->subprocess_env, "downgrade-1.0")) {
        proto_num = HTTP_VERSION(1,0);
    }

    if (proto_num == HTTP_VERSION(1,0)
        && apr_table_get(r->subprocess_env, "force-response-1.0"))
    {
        return "HTTP/1.0";
    }

    return AP_SERVER_PROTOCOL;
}

/**
 * Old-style (serial) audit logger.
 */
static int sec_audit_logger_serial(request_rec *r, request_rec *origr, sec_dir_config *dcfg, modsec_rec *msr) {
    char *the_request = origr->the_request;
    const char *status_line = NULL;
    const char *protocol = NULL;
    const char *error_notes = NULL;
    unsigned int o1size = 0, o2size = 0;
    char *o1 = NULL, *o2 = NULL;
    const apr_array_header_t *arr;
    apr_table_entry_t *te;
    apr_size_t nbytes = 0, nbytes_written;
    apr_status_t rv;
    char *vcombinedus, *t;
    int i = 0;

    sec_debug_log(r, 2, "sec_audit_logger_serial: start");

    /* Return silently if we don't have a request line. This
     * means we will not be logging request timeouts.
     */
    if (the_request == NULL) {
        sec_debug_log(r, 4, "sec_audit_logger_serial: skipping, the_request is null");
        return DECLINED;
    }

    vcombinedus = construct_log_vcombinedus(r, origr);
    if (vcombinedus == NULL) return DECLINED;

    status_line = (r->status_line != NULL) ? r->status_line : ap_get_status_line(r->status);
    protocol = get_response_protocol(r);

    /* see if there is an error message stored in notes */
    error_notes = (char *)apr_table_get(r->notes, "error-notes");

    /* before allocating the first buffer, determine the size
     * of data; start with a reasonable number for the data we
     * ourselves produce, add the overhead, add the_request,
     * and input headers
     */
    o1size = 1024; /* allow some space for the overhead */
    o1size += strlen(vcombinedus);
    o1size += strlen(msr->new_auditlog_boundary);
    o1size += strlen(the_request) * 4; /* It can grow after it is escaped */
    arr = apr_table_elts(r->headers_in);
    te = (apr_table_entry_t *)arr->elts;
    for (i = 0; i < arr->nelts; i++) {
        o1size += strlen(te[i].key);
        o1size += strlen(te[i].val);
        o1size += 5;
    }

    if (error_notes != NULL) o1size += strlen(error_notes) * 4;

    o1 = apr_palloc(r->pool, o1size + 1);
    if ((o1 == NULL)||(o1size + 1 == 0)) {
        sec_debug_log(r, 1, "sec_audit_logger: Could not allocate output buffer #1 [asked for %lu]", o1size + 1);
        return DECLINED;
    }

    strcpy(o1, "==");
    strncat(o1, msr->new_auditlog_boundary, o1size - strlen(o1));
    strncat(o1, "==============================\n", o1size - strlen(o1));

    t = apr_psprintf(r->pool, "Request: %s\n", vcombinedus);
    strncat(o1, t, o1size - strlen(o1));

    if (r->handler != NULL) {
        t = apr_psprintf(r->pool, "Handler: %s\n", log_escape_nq(r->pool, (char *)r->handler));
        strncat(o1, t, o1size - strlen(o1));
    }

    if (error_notes != NULL) {
        t = apr_psprintf(r->pool, "Error: %s\n", log_escape_nq(r->pool, (char *)error_notes));
        strncat(o1, t, o1size - strlen(o1));
    }

    strncat(o1, "----------------------------------------\n", o1size - strlen(o1));

    /* request line */
    t = apr_psprintf(r->pool, "%s\n", the_request);
    strncat(o1, t, o1size - strlen(o1));

    /* input headers */
    arr = apr_table_elts(r->headers_in);
    te = (apr_table_entry_t *)arr->elts;
    for (i = 0; i < arr->nelts; i++) {
        t = apr_psprintf(r->pool, "%s: %s\n", te[i].key, te[i].val);
        strncat(o1, t, o1size - strlen(o1));
    }

    strncat(o1, "\n", o1size - strlen(o1));

    /* determine the size of the second buffer */
    o2size = 1024;
    o2size += strlen(msr->new_auditlog_boundary);
    if (status_line != NULL) o2size += strlen(status_line);
    else o2size += 10;

    arr = apr_table_elts(r->headers_out);
    te = (apr_table_entry_t *)arr->elts;
    for (i = 0; i < arr->nelts; i++) {
        o2size += strlen(te[i].key);
        o2size += strlen(te[i].val);
        o2size += 5;
    }

    o2 = apr_palloc(r->pool, o2size + 1);
    if ((o2 == NULL)||(o2size + 1 == 0)) {
        sec_debug_log(r, 1, "sec_audit_logger: Could not allocate output buffer #2 [asked for %lu]", o2size + 1);
        return DECLINED;
    }
    *o2 = '\0';

    /* We don't log the headers when HTTP 0.9 is used */
    if (!r->assbackwards) {
        if (status_line != NULL) {
            t = apr_psprintf(r->pool, "%s %s\n", protocol, status_line);
        } else {
            t = apr_psprintf(r->pool, "%s %i\n", protocol, r->status);
        }
        strncat(o2, t, o2size - strlen(o2));

        /* output headers */
        arr = apr_table_elts(r->headers_out);
        te = (apr_table_entry_t *)arr->elts;
        for (i = 0; i < arr->nelts; i++) {
            t = apr_psprintf(r->pool, "%s: %s\n", te[i].key, te[i].val);
            strncat(o2, t, o2size - strlen(o2));
        }

        /* we do not need to be concerned with err_headers_out
         * at this point because they were already merged with
         * headers_out by now
         */
    }

    /* The footer */
    strncat(o2, "--", o2size - strlen(o2));
    strncat(o2, msr->new_auditlog_boundary, o2size - strlen(o2));
    strncat(o2, "--\n\n", o2size - strlen(o2));


    /* Write to the file */

    rv = apr_global_mutex_lock(modsec_auditlog_lock);
    if (rv != APR_SUCCESS) {
        ap_log_error(APLOG_MARK, APLOG_ERR, rv, r->server, "mod_post_log: apr_global_mutex_lock(modsec_auditlog_lock) failed");
    }

    nbytes = strlen(o1);
    apr_file_write_full(dcfg->auditlog_fd, o1, nbytes, &nbytes_written);

    {
        int body_action = 0; /* body not available by default */
        char *message = NULL, *filename = NULL;

        sec_debug_log(r, 9, "sec_audit_logger_serial: is_relevant=%i, should_body_exist=%i, is_body_read=%i", msr->is_relevant, msr->should_body_exist, msr->is_body_read);

        /* determine what we need to do here */
        if (msr->should_body_exist == 1) {
            if ((msr->is_body_read == 0)||(msr->ctx_in == NULL)) {
                body_action = 0; /* no payload (i.e. we did not read it) */
            } else {
                if (msr->ctx_in->type != POST_IN_MEMORY) {
                    msr->ctx_in->tmp_file_mode = REQBODY_FILE_LEAVE;
                    body_action = 2; /* reference external files in the audit log */

                    /* Use only the base filename. If files
                     * get moved around, absolute references
                     * won't work.
                     */
                    filename = strrchr(msr->ctx_in->tmp_file_name, '/');
                    if (filename == NULL) filename = msr->ctx_in->tmp_file_name;
                    else filename = filename + 1;
                } else {
                    body_action = 1; /* write from memory directly into a file */
                }
            }
        } else {
            body_action = 3; /* do nothing (request had no payload) */
        }

        /* now generate the message */
        message = NULL;
        switch(body_action) {
            case 0 :
                message = "[POST payload not available]";
                nbytes = strlen(message);
                break;
            case 1 :
                message = msr->ctx_in->buffer;
                nbytes = msr->ctx_in->buflen;
                break;
            case 2 :
                message = apr_psprintf(r->pool, "[@file:%s]", filename);
                nbytes = strlen(message);
                break;
            case 3 :
            default :
                /* do nothing */
                break;
        }

        /* write the message */
        if (message != NULL) {
            char *o3 = apr_psprintf(r->pool, "%lu\n", (unsigned long)nbytes);
            apr_size_t o3nbytes = strlen(o3);

            /* We first write out the size of the payload */
            apr_file_write_full(dcfg->auditlog_fd, o3, o3nbytes, &nbytes_written);

            /* and then the payload itself */
            apr_file_write_full(dcfg->auditlog_fd, message, nbytes, &nbytes_written);

            message = "\n\n";
            nbytes = 2;
            apr_file_write_full(dcfg->auditlog_fd, message, nbytes, &nbytes_written);
        }
    }

    /* write the second part of the log */
    nbytes = strlen(o2);
    apr_file_write_full(dcfg->auditlog_fd, o2, nbytes, &nbytes_written);

    rv = apr_global_mutex_unlock(modsec_auditlog_lock);
    if (rv != APR_SUCCESS) {
        ap_log_error(APLOG_MARK, APLOG_ERR, rv, r->server, "mod_log_post: apr_global_mutex_unlock(modsec_auditlog_lock) failed");
    }

    return OK;
}

/**
 * Initialise new-style audit logging.
 */
void sec_auditlog_init(modsec_rec *msr) {
    request_rec *r = msr->r;

    /* the boundary is used by both audit log types */
    msr->new_auditlog_boundary = create_auditlog_boundary(msr->r);

    /* Return silently if we don't have a request line. This
     * means we will not be logging request timeouts.
     */
    if (msr->r->the_request == NULL) {
        sec_debug_log(r, 4, "Audit log initialisation: skipping, the_request is null");
        return;
    }

    if ((msr->dcfg->auditlog_fd == NULL)||(msr->dcfg->auditlog_fd == NOT_SET_P)) {
        sec_debug_log(r, 4, "Audit log initialisation: skipping, auditlog_fd is null");
        return;
    }

    return;
}

char *log_escape(apr_pool_t *p, char *text) {
    return _log_escape(p, text, 1, 0);
}

char *log_escape_nq(apr_pool_t *p, char *text) {
    return _log_escape(p, text, 0, 0);
}

/**
 * Transform input into a form safe for logging.
 */
char *_log_escape(apr_pool_t *p, char *text, int escape_quotes, int escape_colon) {
    const unsigned char *s = NULL;
    unsigned char *d = NULL;
    char *ret = NULL;

    if (text == NULL) return NULL;

    ret = apr_palloc(p, strlen(text) * 4 + 1);
    if (ret == NULL) return NULL;
    s = (const unsigned char *)text;
    d = (unsigned char *)ret;

    while(*s != 0) {
        switch(*s) {
            case ':' :
                if (escape_colon) {
                    *d++ = '\\';
                    *d++ = ':';
                } else {
                    *d++ = *s;
                }
                break;
            case '"' :
                if (escape_quotes) {
                    *d++ = '\\';
                    *d++ = '"';
                } else {
                    *d++ = *s;
                }
                break;
            case '\b' :
                *d++ = '\\';
                *d++ = 'b';
                break;
            case '\n' :
                *d++ = '\\';
                *d++ = 'n';
                break;
            case '\r' :
                *d++ = '\\';
                *d++ = 'r';
                break;
            case '\t' :
                *d++ = '\\';
                *d++ = 't';
                break;
            case '\v' :
                *d++ = '\\';
                *d++ = 'v';
                break;
            case '\\' :
                *d++ = '\\';
                *d++ = '\\';
                break;
            default :
                if ((*s <= 0x1f)||(*s >= 0x7f)) {
                    *d++ = '\\';
                    *d++ = 'x';
                    c2x(*s, d);
                    d += 2;
                } else {
                    *d++ = *s;
                }
                break;
        }
        s++;
    }
    *d = 0;

    return ret;
}

/**
 *
 */
static void sec_debug_log(request_rec *r, int level, const char *text, ...) {
    sec_dir_config *dcfg = (sec_dir_config *)ap_get_module_config(r->per_dir_config, &log_post_module);
    va_list ap;
    char str1[1024] = "";
    char str2[1256] = "";
    apr_size_t nbytes, nbytes_written;
    apr_file_t *debuglog_fd = NULL;
    int filter_debug_level = 0;

    if (dcfg != NULL) {
        if ((dcfg->debuglog_fd != NULL)&&(dcfg->debuglog_fd != NOT_SET_P)) debuglog_fd = dcfg->debuglog_fd;
        if (dcfg->filter_debug_level != NOT_SET) filter_debug_level = dcfg->filter_debug_level;
    }

    /* Return immediately if we don't have where to write
     * or if the log level of the message is higher than
     * wanted in the log.
     */
    if ((level != 1)&&( (debuglog_fd == NULL) || (level > filter_debug_level) )) return;

    va_start(ap, text);

    apr_vsnprintf(str1, sizeof(str1), text, ap);
    apr_snprintf(str2, sizeof(str2), "[%s] [%s/sid#%lx][rid#%lx][%s][%i] %s\n", current_logtime(r), ap_get_server_name(r), (unsigned long)(r->server), (unsigned long)r, ((r->uri == NULL) ? "" : log_escape_nq(r->pool, r->uri)), level, str1);

    if ((debuglog_fd != NULL)&&(level <= filter_debug_level)) {
        nbytes = strlen(str2);
        apr_file_write_full(debuglog_fd, str2, nbytes, &nbytes_written);
    }

    if (level == 1) {
        char *unique_id = (char *)get_env_var(r, "UNIQUE_ID");
        char *hostname = (char *)r->hostname;

        if (unique_id != NULL) unique_id = apr_psprintf(r->pool, " [unique_id \"%s\"]", log_escape(r->pool, unique_id));
        else unique_id = "";

        if (hostname != NULL) hostname = apr_psprintf(r->pool, " [hostname \"%s\"]", log_escape(r->pool, hostname));
        else hostname = "";

        ap_log_error(APLOG_MARK, APLOG_ERR | APLOG_NOERRNO, 0, r->server, "[client %s] mod_log_post: %s%s [uri \"%s\"]%s", r->connection->remote_ip, str1, hostname, log_escape(r->pool, r->unparsed_uri), unique_id);
    }

    va_end(ap);
    return;
}

char *current_logtime(request_rec *r) {
    apr_time_exp_t t;
    char tstr[100];
    apr_size_t len;

    apr_time_exp_lt(&t, apr_time_now());

    apr_strftime(tstr, &len, 80, "%d/%b/%Y:%H:%M:%S ", &t);
    apr_snprintf(tstr + strlen(tstr), 80 - strlen(tstr), "%c%.2d%.2d",
        t.tm_gmtoff < 0 ? '-' : '+',
        t.tm_gmtoff / (60 * 60), t.tm_gmtoff % (60 * 60));
    return apr_pstrdup(r->pool, tstr);
}

char *current_filetime(request_rec *r) {
    apr_time_exp_t t;
    char tstr[100];
    apr_size_t len;

    apr_time_exp_lt(&t, apr_time_now());

    apr_strftime(tstr, &len, 80, "%Y%m%d-%H%M%S", &t);
    return apr_pstrdup(r->pool, tstr);
}

/* -- Multipart functions (PMULTIPART) ------------------------------------- */

int multipart_contains_files(multipart_data *mpd) {
    multipart_part **parts;
    int i, file_count = 0;

    parts = (multipart_part **)mpd->parts->elts;
    for(i = 0; i < mpd->parts->nelts; i++) {
        if ((parts[i]->type == MULTIPART_FILE)
            && (parts[i]->filename != NULL)
            && (strlen(parts[i]->filename) != 0)) file_count++;
    }

    return file_count;
}

multipart_part *multipart_get_part(multipart_data *mpd, char *name) {
    multipart_part **parts;
    int i;

    parts = (multipart_part **)mpd->parts->elts;
    for(i = 0; i < mpd->parts->nelts; i++) {
        if (strcasecmp(parts[i]->name, name) == 0) return parts[i];
    }

    return NULL;
}

int multipart_check_files_names(modsec_rec *msr, signature *sig, variable *var) {
    multipart_data *mpd = msr->mpd;
    multipart_part **parts;
    int i, rs;

    parts = (multipart_part **)mpd->parts->elts;
    for(i = 0; i < mpd->parts->nelts; i++) {
        if ((parts[i]->type == MULTIPART_FILE)&&(parts[i]->filename != NULL)) {
            sec_debug_log(msr->r, 4, "Checking signature \"%s\" at FILES_NAMES(%s)", log_escape(msr->r->pool, sig->pattern), log_escape(msr->r->pool, parts[i]->name));
            rs = check_sig_against_string(msr, sig, parts[i]->filename, VAR_FILES_NAMES, parts[i]->name);
            if (rs != OK) return rs;
        }
    }

    return OK;
}

int multipart_check_files_sizes(modsec_rec *msr, signature *sig, variable *var) {
    multipart_data *mpd = msr->mpd;
    multipart_part **parts;
    int i, rs;

    parts = (multipart_part **)mpd->parts->elts;
    for(i = 0; i < mpd->parts->nelts; i++) {
        if ((parts[i]->type == MULTIPART_FILE)&&(parts[i]->filename != NULL)) {
            char *size_string = apr_psprintf(msr->r->pool, "%u", parts[i]->tmp_file_size);
            sec_debug_log(msr->r, 4, "Checking signature \"%s\" at FILES_SIZES(\"%s\")", log_escape(msr->r->pool, sig->pattern), log_escape(msr->r->pool, parts[i]->name));
            rs = check_sig_against_string(msr, sig, size_string, VAR_FILES_SIZES, parts[i]->name);
            if (rs != OK) return rs;
        }
    }

    return OK;
}

char *construct_put_filename(modsec_rec *msr) {
    char c, *put_file_name = NULL;
    char *tmp_dir = NULL, *t = NULL;

    put_file_name = apr_pstrdup(msr->r->pool, msr->r->uri);
    t = strstr(put_file_name, "?");
    if (t != NULL) *t = 0;

    t = strrchr(put_file_name, '/');
    if (t != NULL) put_file_name = t + 1;

    /* allow letters, digits and dots, nuke the rest */
    t = put_file_name;
    while((c = *t) != 0) {
        if (!( isalnum(c)||(c == '.') )) *t = '_';
        t++;
    }

    tmp_dir = get_temp_folder(msr->r->pool);

    return apr_psprintf(msr->r->pool, "%s/%s-%s-%s", tmp_dir, current_filetime(msr->r), msr->r->connection->remote_ip, put_file_name);
}

apr_status_t request_body_file_cleanup(void *data) {
    modsec_rec *msr = (modsec_rec *)data;
    char *put_filename = NULL;

    if (msr == NULL) return -1;
    sec_debug_log(msr->r, 4, "request_body_file_cleanup: Started");

    /* only continue if there is a temporary file */
    if ((msr->ctx_in == NULL)||(msr->ctx_in->tmp_file_name == NULL)) return -1;

    if (msr->ctx_in->is_put) {
        put_filename = construct_put_filename(msr);
    }

    /* The new-style audit log makes no use of the temporary
     * request body; in such cases we don't have to copy it, just rename it.
     * But this function does not need to think about it because mode will
     * be REQBODY_FILE_DELETE.
     */
    if (msr->ctx_in->tmp_file_mode == REQBODY_FILE_LEAVE) {
        return 1;
    }

    /* Poor file, nobody wants you */
    if (unlink(msr->ctx_in->tmp_file_name) < 0) {
        sec_debug_log(msr->r, 1, "request_body_file_cleanup: Failed to delete file \"%s\" because %d(\"%s\")", log_escape(msr->r->pool, msr->ctx_in->tmp_file_name), errno, log_escape(msr->r->pool, strerror(errno)));
    } else {
        sec_debug_log(msr->r, 2, "request_body_file_cleanup: Deleted file \"%s\"", log_escape(msr->r->pool, msr->ctx_in->tmp_file_name));
    }

    return 1;
}

apr_status_t multipart_cleanup(void *data) {
    multipart_data *mpd = (multipart_data *)data;

    if (data == NULL) return -1;
    sec_debug_log(mpd->r, 4, "multipart_cleanup: Started");

    /* loop through the list of parts
     * and delete the temporary files, but only if
     * file storage was not requested, or if storage
     * of relevant files was requested and this isn't
     * such a request
     */

    multipart_part **parts;
    int i;

    parts = (multipart_part **)mpd->parts->elts;
    for(i = 0; i < mpd->parts->nelts; i++) {
        if (parts[i]->type == MULTIPART_FILE) {
            if (parts[i]->tmp_file_name != NULL) {
                sec_debug_log(mpd->r, 4, "multipart_cleanup: deleting temporary file (part) \"%s\"", log_escape(mpd->r->pool, parts[i]->tmp_file_name));
                if (unlink(parts[i]->tmp_file_name) < 0) {
                    sec_debug_log(mpd->r, 1, "multipart_cleanup: Failed to delete file (part) \"%s\" because %d(%s)", log_escape(mpd->r->pool, parts[i]->tmp_file_name), errno, strerror(errno));
                } else {
                    sec_debug_log(mpd->r, 2, "multipart_cleanup: Deleted file (part) \"%s\"", log_escape(mpd->r->pool, parts[i]->tmp_file_name));
                }
            }
        }
    }

    return 1;
}

int multipart_init(multipart_data *mpd, modsec_rec *msr, char **error_msg) {
    request_rec *r = msr->r;
    char *content_type;

    if (error_msg == NULL) return -1;
    *error_msg = NULL;

    mpd->dcfg = msr->dcfg;
    mpd->p = r->pool;
    mpd->msr = msr;
    mpd->r = msr->r;

    content_type = (char *)apr_table_get(r->headers_in, "Content-Type");
    if (content_type == NULL) {
        *error_msg = apr_psprintf(r->pool, "multipart_init: Content-Type header not available");
        return -1;
    }

    mpd->boundary = strstr(content_type, "boundary=");
    if ((mpd->boundary != NULL)&&(*(mpd->boundary + 9) != 0)) mpd->boundary = mpd->boundary + 9;
    else {
        *error_msg = apr_psprintf(r->pool, "multipart_init: Boundary not found or invalid");
        return -1;
    }

    mpd->parts = apr_array_make(mpd->p, 10, sizeof(multipart_part *));
    mpd->bufleft = MULTIPART_BUF_SIZE;
    mpd->bufptr = mpd->buf;
    mpd->buf_contains_line = 1;
    mpd->mpp = NULL;

    /* schedule resource cleanup for later */
    apr_pool_cleanup_register(r->pool, (void *)mpd, multipart_cleanup, apr_pool_cleanup_null);

    return 1;
}

int multipart_process_chunk(multipart_data *mpd, const char *buf, unsigned int size, char **error_msg) {
    char *inptr = (char *)buf;
    unsigned int inleft = size;

    if (error_msg == NULL) return -1;
    *error_msg = NULL;

    if (size == 0) return 1;

    if (mpd->seen_data == 0) mpd->seen_data = 1;

    if (mpd->is_complete) {
        sec_debug_log(mpd->r, 4, "Multipart: ignoring data after last boundary (received %i bytes)", size);
        return 1;
    }

    if (mpd->bufleft == 0) {
        *error_msg = apr_psprintf(mpd->r->pool, "Multipart: internal error in process_chunk: no more space in the buffer");
        return -1;
    }

    /* here we loop through the data available, byte by byte */
    while(inleft > 0) {
        char c = *inptr;
        int process_buffer = 0;

        if ((c == 0x0d)&&(mpd->bufleft == 1)) {
            /* we don't want to take 0x0d as the last byte in the buffer */
            process_buffer = 1;
        } else {
            inptr++;
            inleft = inleft - 1;

            *(mpd->bufptr) = c;
            mpd->bufptr++;
            mpd->bufleft--;
        }

        /* until we either reach the end of the line
         * or the end of our internal buffer
         */
        if ((c == 0x0a)||(mpd->bufleft == 0)||(process_buffer)) {
            *(mpd->bufptr) = 0;

            /* boundary preconditions: length of the line greater than
             * the length of the boundary + the first two characters
             * are dashes "-"
             */
            if ( mpd->buf_contains_line
                && (strlen(mpd->buf) > strlen(mpd->boundary) + 2)
                && (((*(mpd->buf) == '-'))&&(*(mpd->buf + 1) == '-'))
                && (strncmp(mpd->buf + 2, mpd->boundary, strlen(mpd->boundary)) == 0) ) {

                char *boundary_end = mpd->buf + 2 + strlen(mpd->boundary);

                if (  (*boundary_end == '\r')
                    &&(*(boundary_end + 1) == '\n')
                    &&(*(boundary_end + 2) == '\0')
                ) {
                    /* simple boundary */
                    if (multipart_process_boundary(mpd, 0, error_msg) < 0) return -1;
                }
                else
                if (  (*boundary_end == '-')
                    &&(*(boundary_end + 1) == '-')
                    &&(*(boundary_end + 2) == '\r')
                    &&(*(boundary_end + 3) == '\n')
                    &&(*(boundary_end + 4) == '\0')
                ) {
                    /* final boundary */
                    mpd->is_complete = 1;
                    if (multipart_process_boundary(mpd, 1, error_msg) < 0) return -1;
                }
                else {
                    /* error */
                    *error_msg = apr_psprintf(mpd->r->pool, "Multipart: invalid boundary encountered: %s", log_escape_nq(mpd->r->pool, mpd->buf));
                    return -1;
                }
            }
            else {
                if (mpd->mpp == NULL) {
                    sec_debug_log(mpd->r, 4, "Multipart: ignoring data before first boundary");
                } else {
                    if (mpd->mpp_state == 0) {
                        if ((mpd->bufleft == 0)||(process_buffer)) {
                            /* part header lines must be shorter than
                             * MULTIPART_BUF_SIZE bytes
                             */
                            *error_msg = apr_psprintf(mpd->r->pool, "Multipart: part header line over %i bytes long", MULTIPART_BUF_SIZE);
                            return -1;
                        }
                        if (multipart_process_part_header(mpd, error_msg) < 0) return -1;
                    } else {
                        if (multipart_process_part_data(mpd, error_msg) < 0) return -1;
                    }
                }
            }

            /* reset the pointer to the beginning of the buffer
             * and continue to accept input data
             */
            mpd->bufptr = mpd->buf;
            mpd->bufleft = MULTIPART_BUF_SIZE;
            mpd->buf_contains_line = (c == 0x0a) ? 1 : 0;
        }

        if ((mpd->is_complete)&&(inleft != 0)) {
            sec_debug_log(mpd->r, 4, "Multipart: ignoring data after last boundary (%i bytes left)", inleft);
            return 1;
        }
    }

    return 1;
}

int multipart_parse_content_disposition(multipart_data *mpd, char *value) {
    char *p = NULL, *t = NULL;

    /* accept only what we understand */
    if (strncmp(value, "form-data", 9) != 0) {
        return -1;
    }

    /* see if there are any other parts to parse */

    p = value + 9;
    while((*p == '\t')||(*p == ' ')) p++;
    if (*p == '\0') return 1; /* this is OK */

    if (*p != ';') return -2;
    p++;

    /* parse the appended parts */

    while(*p != '\0') {
        char *name = NULL, *value = NULL, *start = NULL;

        /* go over the whitespace */
        while((*p == '\t')||(*p == ' ')) p++;
        if (*p == '\0') return -3;

        start = p;
        while((*p != '\0')&&(*p != '=')&&(*p != '\t')&&(*p != ' ')) p++;
        if (*p == '\0') return -4;

        name = apr_pstrmemdup(mpd->r->pool, start, (p - start));

        while((*p == '\t')||(*p == ' ')) p++;
        if (*p == '\0') return -5;

        if (*p != '=') return -13;
        p++;

        while((*p == '\t')||(*p == ' ')) p++;
        if (*p == '\0') return -6;

        if (*p == '"') {
            /* quoted */

            p++;
            if (*p == '\0') return -7;

            start = p;
            value = apr_pstrdup(mpd->r->pool, p);
            t = value;

            while(*p != '\0') {
                if (*p == '\\') {
                    if (*(p + 1) == '\0') {
                        /* improper escaping */
                        return -8;
                    }
                    /* only " and \ can be escaped */
                    if ((*(p + 1) == '"')||(*(p + 1) == '\\')) {
                        p++;
                    }
                    else {
                        /* improper escaping */

                        /* We allow for now because IE sends
                         * improperly escaped content and there's
                         * nothing we can do about it.
                         *
                         * return -9;
                         */
                    }
                }
                else
                if (*p == '"') {
                    *t = '\0';
                    break;
                }

                *t++ = *p++;
            }
            if (*p == '\0') return -10;

            p++; /* go over the quote at the end */

        } else {
            /* not quoted */

            start = p;
            while((*p != '\0')&&(is_token_char(*p))) p++;
            value = apr_pstrmemdup(mpd->r->pool, start, (p - start));
        }

        /* evaluate part */

        if (strcmp(name, "name") == 0) {
            if (mpd->mpp->name != NULL) return -14;
            mpd->mpp->name = value;
            sec_debug_log(mpd->r, 9, "multipart_parse_content_disposition: name %s", log_escape_nq(mpd->r->pool, value));
        }
        else
        if (strcmp(name, "filename") == 0) {
            if (mpd->mpp->filename != NULL) return -15;
            mpd->mpp->filename = value;
            sec_debug_log(mpd->r, 9, "multipart_parse_content_disposition: filename %s", log_escape_nq(mpd->r->pool, value));
        }
        else return -11;

        if (*p != '\0') {
            while((*p == '\t')||(*p == ' ')) p++;
            /* the next character must be a zero or a semi-colon */
            if (*p == '\0') return 1; /* this is OK */
            if (*p != ';') return -12;
            p++; /* move over the semi-colon */
        }

        /* loop will stop when (*p == '\0') */
    }

    return 1;
}

int multipart_process_part_header(multipart_data *mpd, char **error_msg) {
    int rc;

    if (error_msg == NULL) return -1;
    *error_msg = NULL;

    if ((mpd->buf[0] == '\r')&&(mpd->buf[1] == '\n')&&(mpd->buf[2] == '\0')) {
        char *header_value;

        /* empty line */

        header_value = (char *)apr_table_get(mpd->mpp->headers, "Content-Disposition");
        if (header_value == NULL) {
            *error_msg = apr_psprintf(mpd->r->pool, "Multipart: part is missing the Content-Disposition header");
            return -1;
        }

        rc = multipart_parse_content_disposition(mpd, header_value);
        if (rc < 0) {
            *error_msg = apr_psprintf(mpd->r->pool, "Multipart: invalid Content-Disposition header (%i): %s", rc, log_escape_nq(mpd->r->pool, header_value));
            return -1;
        }

        if (mpd->mpp->name == NULL) {
            *error_msg = apr_psprintf(mpd->r->pool, "Multipart: part name missing");
            return -1;
        }

        if (mpd->mpp->filename != NULL) {
            mpd->mpp->type = MULTIPART_FILE;
        } else {
            mpd->mpp->type = MULTIPART_FORMDATA;
        }

        mpd->mpp_state = 1;
        mpd->mpp->last_header_name = NULL;
    } else {
        /* header line */
        if ((mpd->buf[0] == '\t')||(mpd->buf[0] == ' ')) {
            char *header_value, *new_value, *data;

            /* header folding, add data to the header we are building */

            if (mpd->mpp->last_header_name == NULL) {
                /* we are not building a header at this moment */
                *error_msg = apr_psprintf(mpd->r->pool, "Multipart: invalid part header (invalid folding)");
                return -1;
            }

            /* locate the beginning of the data */
            data = mpd->buf;
            while((*data == '\t')||(*data == ' ')) data++;

            new_value = apr_pstrdup(mpd->r->pool, data);
            sec_remove_lf_crlf_inplace(new_value);

            /* update the header value in the table */
            header_value = (char *)apr_table_get(mpd->mpp->headers, mpd->mpp->last_header_name);
            new_value = apr_pstrcat(mpd->r->pool, header_value, " ", new_value, NULL);
            apr_table_set(mpd->mpp->headers, mpd->mpp->last_header_name, new_value);

            sec_debug_log(mpd->r, 9, "multipart_process_par_header: continued folder header \"%s\" with \"%s\"", log_escape(mpd->r->pool, mpd->mpp->last_header_name), log_escape(mpd->r->pool, data));

            if (strlen(new_value) > 4096) {
                *error_msg = apr_psprintf(mpd->r->pool, "Multpart: invalid part header (too long)");
                return -1;
            }
        } else {
            char *header_name, *header_value, *data;

            /* new header */

            data = mpd->buf;
            while((*data != ':')&&(*data != '\0')) data++;
            if (*data == '\0') {
                *error_msg = apr_psprintf(mpd->r->pool, "Multipart: invalid part header (missing colon): %s", log_escape_nq(mpd->r->pool, mpd->buf));
                return -1;
            }

            header_name = apr_pstrmemdup(mpd->r->pool, mpd->buf, (data - mpd->buf));

            /* extract the value value */
            data++;
            while((*data == '\t')||(*data == ' ')) data++;
            header_value = apr_pstrdup(mpd->r->pool, data);
            sec_remove_lf_crlf_inplace(header_value);

            /* error if the name already exists */
            if (apr_table_get(mpd->mpp->headers, header_name) != NULL) {
                *error_msg = apr_psprintf(mpd->r->pool, "Multipart: part header already exists: %s", log_escape_nq(mpd->r->pool, header_name));
                return -1;
            }

            apr_table_setn(mpd->mpp->headers, header_name, header_value);
            mpd->mpp->last_header_name = header_name;

            sec_debug_log(mpd->r, 9, "multipart_process_par_header: added part header \"%s\" \"%s\"", log_escape(mpd->r->pool, header_name), log_escape(mpd->r->pool, header_value));
        }
    }

    return 1;
}

int multipart_process_part_data(multipart_data *mpd, char **error_msg) {
    char *p = mpd->buf + (MULTIPART_BUF_SIZE - mpd->bufleft) - 2;
    char localreserve[2] = { '\0', '\0' }; /* initialized to quiet warning */
    int bytes_reserved = 0;

    if (error_msg == NULL) return -1;
    *error_msg = NULL;

    /* preserve the last two bytes for later */
    if (MULTIPART_BUF_SIZE - mpd->bufleft >= 2) {
        bytes_reserved = 1;
        localreserve[0] = *p;
        localreserve[1] = *(p + 1);
        mpd->bufleft += 2;
        *p = 0;
    }

    /* add data to the part we are building */
    if (mpd->mpp->type == MULTIPART_FILE) {
        /* just keep track of the file size */
        if (mpd->reserve[0] == 1) mpd->mpp->tmp_file_size += 2;
        mpd->mpp->tmp_file_size += (MULTIPART_BUF_SIZE - mpd->bufleft);
    }
    else if (mpd->mpp->type == MULTIPART_FORMDATA) {
        char *value_part = NULL;

        /* add this part to the list of parts */

        if (mpd->reserve[0] == 1) {
            value_part = apr_pstrcat(mpd->p, &(mpd->reserve[1]), mpd->buf, NULL);
        } else {
            value_part = apr_pstrdup(mpd->p, mpd->buf);
        }

        *(char **)apr_array_push(mpd->mpp->value_parts) = value_part;
        sec_debug_log(mpd->r, 9, "Added data to variable: %s", log_escape_nq(mpd->r->pool, value_part));
    }
    else {
        *error_msg = apr_psprintf(mpd->r->pool, "Multipart: unknown part type %i", mpd->mpp->type);
        return -1;
    }

    /* store the reserved bytes to the multipart
     * context so that they don't get lost
     */
    if (bytes_reserved) {
        mpd->reserve[0] = 1;
        mpd->reserve[1] = localreserve[0];
        mpd->reserve[2] = localreserve[1];
    }
    else {
        mpd->reserve[0] = 0;
    }

    return 1;
}

int multipart_complete(multipart_data *mpd, char **error_log) {
    if ((mpd->seen_data != 0)&&(mpd->is_complete == 0)) {
        *error_log = apr_psprintf(mpd->r->pool, "Multipart: final boundary missing");
        return -1;
    }
    return 1;
}

int multipart_process_boundary(multipart_data *mpd, int last_part, char **error_log) {
    sec_debug_log(mpd->r, 4, "multipart_process_boundary: last_part = %i", last_part);

    /* if there was a part being built finish it */
    if (mpd->mpp != NULL) {
        /* close the temp file */
        if ((mpd->mpp->type == MULTIPART_FILE)&&(mpd->mpp->tmp_file_name != NULL)&&(mpd->mpp->tmp_file_fd != 0)) {
            close(mpd->mpp->tmp_file_fd);
        }

        if (mpd->mpp->type != MULTIPART_FILE) {
            /* now construct a single string out of the parts */
            mpd->mpp->value = apr_array_pstrcat(mpd->r->pool, mpd->mpp->value_parts, 0);
            if (mpd->mpp->value == NULL) return -1;
        }

        /* add the part to the list of parts */
        *(multipart_part **)apr_array_push(mpd->parts) = mpd->mpp;
        if (mpd->mpp->type == MULTIPART_FILE) sec_debug_log(mpd->r, 9, "multipart_process_boundary: added file part %x to the list: name \"%s\" file name \"%s\" size %u", mpd->mpp, log_escape(mpd->r->pool, mpd->mpp->name), log_escape(mpd->r->pool, mpd->mpp->filename), mpd->mpp->tmp_file_size);
        else sec_debug_log(mpd->r, 9, "multipart_process_boundary: added part %x to the list: name \"%s\"", mpd->mpp, log_escape(mpd->r->pool, mpd->mpp->name));
        mpd->mpp = NULL;
    }

    if (last_part == 0) {
        /* start building a new part */
        mpd->mpp = (multipart_part *)apr_pcalloc(mpd->p, sizeof(multipart_part));
        mpd->mpp->type = MULTIPART_FORMDATA;
        mpd->mpp_state = 0;

        mpd->mpp->headers = apr_table_make(mpd->r->pool, 10);
        mpd->mpp->last_header_name = NULL;

        mpd->reserve[0] = 0;
        mpd->reserve[1] = 0;
        mpd->reserve[2] = 0;
        mpd->reserve[3] = 0;

        mpd->mpp->value_parts = apr_array_make(mpd->r->pool, 10, sizeof(char *));
    }

    return 1;
}

int multipart_get_variables(multipart_data *mpd, apr_table_t *parsed_args, sec_dir_config *dcfg, char **error_msg) {
    multipart_part **parts;
    char *my_error_msg = NULL;
    int i;

    if (error_msg == NULL) return -1;
    *error_msg = NULL;

    parts = (multipart_part **)mpd->parts->elts;
    for(i = 0; i < mpd->parts->nelts; i++) {
        if (parts[i]->type == MULTIPART_FORMDATA) {
            char *name = NULL, *value = NULL;

            name = normalise_relaxed(mpd->r, dcfg, parts[i]->name, &my_error_msg);
            if (name == NULL) {
                *error_msg = apr_psprintf(mpd->r->pool, "Error normalising parameter name: %s", my_error_msg);
                return -1;
            }

            value = normalise_relaxed(mpd->r, dcfg, parts[i]->value, &my_error_msg);
            if (value == NULL) {
                *error_msg = apr_psprintf(mpd->r->pool, "Error normalising parameter value: %s", my_error_msg);
                return -1;
            }

            apr_table_add(parsed_args, name, value);
        }
    }

    return 1;
}


/* -- Core (PCORE) -------------------------------------------------------- */

int sec_initialise(modsec_rec *msr) {
    char *my_error_msg = NULL;
    request_rec *r = msr->r;
    apr_status_t rc;
    const apr_array_header_t *arr;
    apr_table_entry_t *te;
    int i;

    msr->request_uri = normalise(r, msr->dcfg, msr->r->unparsed_uri, &my_error_msg);
    if (msr->request_uri == NULL) {
        msr->tmp_message = apr_psprintf(r->pool, "Error normalising REQUEST_URI: %s", my_error_msg);
        return perform_action(msr, msr->dcfg->actionset, NULL);
    }

    sec_debug_log(r, 4, "Normalised REQUEST_URI: \"%s\"", log_escape(r->pool, msr->request_uri));
    sec_debug_log(r, 2, "Parsing arguments...");

    /* parse and validate GET parameters when available */
    if (r->args != NULL) {
        if (parse_arguments(r->args, msr->parsed_args, r, msr->dcfg, &my_error_msg) < 0) {
            msr->tmp_message = apr_psprintf(r->pool, "Invalid parameters: %s", my_error_msg);
            return perform_action(msr, msr->dcfg->actionset, NULL);
        }
    }

    /* validate headers */
    arr = apr_table_elts(r->headers_in);
    te = (apr_table_entry_t *)arr->elts;
    for (i = 0; i < arr->nelts; i++) {
        char *header_value = NULL;

        if (strncasecmp(te[i].key, "mod_log_post-", 13) == 0) {
            msr->tmp_message= apr_psprintf(r->pool, "mod_log_post: Internal header detected in request: %s", te[i].key);
            return perform_action(msr, msr->dcfg->actionset, NULL);
        }

        /* We need to turn-off the unicode encoding checks for the
         * Referer header because it sometimes contains the information
         * from another web site, and we can't be sure the information
         * will be a valid Unicode text.
         */

        if (normalise_relaxed(r, msr->dcfg, te[i].key, &my_error_msg) == NULL) {
            msr->tmp_message = apr_psprintf(r->pool, "Error validating header name: %s", my_error_msg);
            return perform_action(msr, msr->dcfg->actionset, NULL);
        }
        header_value = normalise_relaxed(r, msr->dcfg, te[i].val, &my_error_msg);
        if (header_value == NULL) {
            msr->tmp_message = apr_psprintf(r->pool, "Error validating header value (%s): %s", te[i].key, my_error_msg);
            return perform_action(msr, msr->dcfg->actionset, NULL);
        }

        /* cache the normalised header value for later */
        apr_table_add(msr->cache_headers_in, te[i].key, header_value);
    }

    /* parse */

    {
        char *content_type = (char *)apr_table_get(r->headers_in, "Content-Type");

        if (content_type != NULL) sec_debug_log(r, 3, "Content-Type is \"%s\"", log_escape(r->pool, content_type));
        else sec_debug_log(r, 3, "Content-Type is not available");

        rc = read_post_payload(msr);
        if (rc < 0) {
            /* the error message prepared by read_post_payload */
            return perform_action(msr, msr->dcfg->actionset, NULL);
        }

        /* go back straight away if there is no body */
        if (!msr->is_body_read) {
            return DECLINED;
        }

        if (msr->r->method_number == M_PUT) {
            sec_debug_log(r, 2, "PUT method detected, request body is file: %s", msr->ctx_in->tmp_file_name);
        }
        else
        if ((content_type != NULL)
            && (strncasecmp(content_type, "application/x-www-form-urlencoded", 33) == 0)
            && (msr->r->method_number == M_POST))
        {
            int j;

            /* Check that the byte range is ok */
            sec_debug_log(r, 3, "Checking byte range in POST payload");
            for (j = 0; j < msr->ctx_in->buflen; j++) {
                int c = ((unsigned char *)msr->ctx_in->buffer)[j];
                if ((c < 0) || (c > 255)) {
                    msr->tmp_message = apr_psprintf(r->pool, "Invalid character detected in POST payload [%i]", c);
                    return perform_action(msr, msr->dcfg->actionset, NULL);
                }
            }

            /* parse post payload */
            if (msr->_post_payload != NULL) {
                sec_debug_log(r, 3, "Parsing variables from POST payload");
                if (parse_arguments(msr->_post_payload, msr->parsed_args, r, msr->dcfg, &my_error_msg) < 0) {
                    msr->tmp_message = apr_psprintf(r->pool, "Error parsing POST parameters: %s", my_error_msg);
                    return perform_action(msr, msr->dcfg->actionset, NULL);
                }

                msr->_post_payload = normalise(r, msr->dcfg, msr->_post_payload, &my_error_msg);
                if (msr->_post_payload == NULL) {
                    msr->tmp_message = apr_psprintf(r->pool, "Error normalising POST payload: %s", my_error_msg);
                    return perform_action(msr, msr->dcfg->actionset, NULL);
                }
            }
        }
        else
        if ((content_type != NULL)
            && (msr->r->method_number == M_POST)
            && (strncasecmp(content_type, "multipart/form-data", 19) == 0)
            && (msr->mpd != NULL) )
        {

            /* get parsed variables */
            if (multipart_get_variables(msr->mpd, msr->parsed_args, msr->dcfg, &my_error_msg) < 0) {
                msr->tmp_message = apr_psprintf(r->pool, "Error parsing multipart parameters: %s", my_error_msg);
                return perform_action(msr, msr->dcfg->actionset, NULL);
            }
        }
        else if (msr->_post_payload != NULL) {
            msr->_post_payload = remove_binary_content(r, msr->_post_payload, msr->_post_len);
            if (msr->_post_payload == NULL) {
                msr->tmp_message = apr_psprintf(r->pool, "Error while removing binary content from POST");
                return perform_action(msr, msr->dcfg->actionset, NULL);
            }
        }
    }

    return DECLINED;
}

void sec_time_checkpoint(modsec_rec *msr, int checkpoint_no) {
    char note[100], note_name[100];
    apr_time_t now;

    now = apr_time_now();
    switch(checkpoint_no) {
        case 1 :
            msr->time_checkpoint_1 = now;
            break;
        case 2 :
            msr->time_checkpoint_2 = now;
            break;
        case 3 :
            msr->time_checkpoint_3 = now;
            break;
        default :
            sec_debug_log(msr->r, 1, "sec_time_checkpoint: Unknown checkpoint: %i", checkpoint_no);
            return;
            break;
    }

    apr_snprintf(note, 99, "%" APR_TIME_T_FMT, (now - msr->r->request_time));
    apr_snprintf(note_name, 99, "time" "%i", checkpoint_no);
    apr_table_set(msr->r->notes, note_name, note);

    sec_debug_log(msr->r, 4, "Time #%i: %" APR_TIME_T_FMT " usec", checkpoint_no, (now - msr->r->request_time));
}

/* Create a per-request modsecurity context. We
 * need this context even if we are not going
 * to do anything.
 */
modsec_rec *sec_create_context(request_rec *r) {
    sec_dir_config *dcfg = (sec_dir_config *)ap_get_module_config(r->per_dir_config, &log_post_module);
    modsec_rec *msr = NULL;
    char *content_length = NULL;

    msr = (modsec_rec *)apr_pcalloc(r->pool, sizeof(*msr));
    msr->r = r;

    /* We will make a copy of the per-dir configuration.
     * WARNING this is a shallow copy, meaning most pointers
     * will remain pointing to the common locations. This
     * is OK for now as we are not changing any of the
     * data we aren't copying.
     */
    msr->dcfg = apr_pcalloc(r->pool, sizeof(sec_dir_config));
    memcpy(msr->dcfg, dcfg, sizeof(sec_dir_config));
    /* Make a deeper copy of the actionset. Still
     * not a 100% deep copy but deep enough for what
     * we change on the per-request basis.
     */
    if ((dcfg->actionset != NULL)&&(dcfg->actionset != NOT_SET_P)) {
        msr->dcfg->actionset = apr_pcalloc(r->pool, sizeof(actionset_t));
        memcpy(msr->dcfg->actionset, dcfg->actionset, sizeof(actionset_t));
    }
    sec_set_dir_defaults(msr->dcfg);

    msr->request_uri = NULL;
    msr->_post_payload = NULL;
    msr->parsed_args = apr_table_make(r->pool, 10);
    msr->parsed_cookies = apr_table_make(r->pool, 10);
    msr->is_relevant = 0;
    msr->is_dynamic = NOT_SET;
    msr->explicit_auditlog = NOT_SET;

    msr->messages = apr_array_make(r->pool, 10, sizeof(char *));

    msr->cache_request_uri = NULL;
    msr->cache_path_info = NULL;
    msr->cache_the_request = NULL;
    msr->cache_query_string = NULL;
    msr->cache_request_basename = NULL;
    msr->cache_script_basename = NULL;
    msr->cache_headers_in = apr_table_make(r->pool, 10);

    content_length = (char *)apr_table_get(r->headers_in, "Content-Length");
    if (content_length == NULL) {
        /* there's no C-L, could be chunked? */
        char *transfer_encoding = (char *)apr_table_get(r->headers_in, "Transfer-Encoding");
        if ((transfer_encoding != NULL)&&(strstr(transfer_encoding, "chunked") != NULL)) {
            msr->should_body_exist = 1;
        } else {
            /* no C-L, no chunked */
            msr->should_body_exist = 0;
        }
    } else {
        /* C-L found */
        msr->should_body_exist = 1;
    }

    /* Store context for others to find */
    store_msr(r, msr);

    return msr;
}

#ifdef ENABLE_EARLY_HOOK
static int sec_check_access_early(request_rec *r) {
    sec_debug_log(r, 2, "Early processing activated");
    return sec_check_access(r);
}
#endif

int sec_check_access(request_rec *r) {
    modsec_rec *msr = NULL;
    int rc, filter_engine;

    sec_debug_log(r, 2, "Detection phase starting (request %x): \"%s\"", r, ((r->the_request == NULL) ? "" : log_escape(r->pool, r->the_request)));

    msr = find_msr(r);

    /* We only continue if this is a main request */
    if (!ap_is_initial_req(r)) {
        sec_debug_log(r, 2, "sec_check_access: Filtering off, not an initial request");

        if ((msr != NULL)&&(msr->ctx_in != NULL)) {
            ap_filter_t *f = r->input_filters;
            int already_there = 0;

            while(f != NULL) {
                if (f->ctx == msr->ctx_in) {
                    already_there = 1;
                    break;
                }
                f = f->next;
            }

            if (already_there == 0) {
                sec_debug_log(r, 2, "sec_check_access: Added sec_filter_in filter (ctx %x)", msr->ctx_in);
                ap_add_input_filter_handle(global_sec_filter_in, msr->ctx_in, r, r->connection);
            }
        }

        return DECLINED;
    }

    #ifdef ENABLE_EARLY_HOOK
    /* If msr exists that means we already run in a previous hook */
    if (msr != NULL) {
        sec_debug_log(r, 4, "sec_check_access: Ignoring request that was already processed");
        return DECLINED;
    }
    #endif

    msr = sec_create_context(r);

    if (msr->dcfg == NULL) {
        sec_debug_log(r, 2, "sec_check_access: Filtering off, dcfg is null");
        return DECLINED;
    }

    filter_engine = msr->dcfg->filter_engine;

    /* refuse to work if the filtering is off */
    if (filter_engine == 0) {
        sec_debug_log(r, 2, "sec_check_access: Filtering off, not enabled here");
        return DECLINED;
    }

    if (r->handler != NULL) msr->is_dynamic = 1;

    /* this variable should be used in the subsequent phases to
     * determine whether to run or not without having to duplicate
     * the complex logic
     */
    msr->is_enabled = 1;

    /* Initialize mod_security structures for this request.
     * As of 1.8.6 non-fatal default actions are not allowed
     * during the initialization phase.
     */
    rc = sec_initialise(msr);

    sec_time_checkpoint(msr, 1);

    /* Process rules only if there were no errors
     * in the initialization stage.
     */
    if (rc == DECLINED) {
        rc = sec_check_all_signatures(msr);
    }

    /* Make a note for the logger */
    if (rc != DECLINED) {
        char *note = apr_psprintf(r->pool, "%i", rc);
        apr_table_setn(r->headers_in, "action", note);
        apr_table_setn(r->subprocess_env, "relevant", "1");
    } else {
        apr_table_unset(r->headers_in, "action");
    }

    /* Export the request body as a note */
    if (msr->is_body_read) {
        char *post_payload = msr->_post_payload;
        if (msr->mpd != NULL) {
            if (msr->_fake_post_payload != NULL) post_payload = msr->_fake_post_payload;
            else post_payload = construct_fake_urlencoded(msr, msr->parsed_args);
        }
        if (post_payload != NULL) apr_table_setn(r->notes, "body", post_payload);
    }

    sec_time_checkpoint(msr, 2);
    return rc;
}

static apr_status_t locks_remove(void *data) {
    if (modsec_auditlog_lock != NULL) {
        apr_global_mutex_destroy(modsec_auditlog_lock);
        modsec_auditlog_lock = NULL;
    }
    return 0;
}

static int sec_init(apr_pool_t *p, apr_pool_t *plog, apr_pool_t *ptemp, server_rec *s) {
    apr_status_t rv;
    void *data = NULL;
    int first_time = 0;

    apr_pool_userdata_get(&data, "sec_init_flag", s->process->pool);
    if (data == NULL) {
        first_time = 1;
        apr_pool_userdata_set((const void *)1, "sec_init_flag", apr_pool_cleanup_null, s->process->pool);
    }

    if ((rv = apr_global_mutex_create(&modsec_auditlog_lock, NULL, APR_LOCK_DEFAULT, p)) != APR_SUCCESS) {
        ap_log_error(APLOG_MARK, APLOG_ERR, rv, s, "mod_log_post: Could not create modsec_auditlog_lock");
        return HTTP_INTERNAL_SERVER_ERROR;
    }

    #ifdef __SET_MUTEX_PERMS
    rv = unixd_set_global_mutex_perms(modsec_auditlog_lock);
    if (rv != APR_SUCCESS) {
        ap_log_error(APLOG_MARK, APLOG_ERR, rv, s, "mod_log_post: Could not set permissions on modsec_auditlog_lock; check User and Group directives");
        return HTTP_INTERNAL_SERVER_ERROR;
    }
    #endif

    apr_pool_cleanup_register(p, (void *)s, locks_remove, apr_pool_cleanup_null);

    return OK;
}

static void sec_child_init(apr_pool_t *pool, server_rec *s) {
    apr_status_t rs;

    if (modsec_auditlog_lock != NULL) {
        rs = apr_global_mutex_child_init(&modsec_auditlog_lock, NULL, pool);
        if (rs != APR_SUCCESS) {
            ap_log_error(APLOG_MARK, APLOG_ERR, rs, s, "Failed to child-init auditlog mutex");
        }
    }

    /* initialise each child process with a different seed */
    srand(time(NULL) * getpid());
}

/* The purpose of this input filter is to break the
 * filter chain in those cases where we have already
 * read the POST data into our buffer. So, instead
 * of getting the data from the next filter in the
 * chain we serve it from our buffer.
 */
static apr_status_t sec_filter_in(ap_filter_t *f, apr_bucket_brigade *pbbOut, ap_input_mode_t eMode, apr_read_type_e eBlock, apr_off_t nBytes) {
    request_rec *r = f->r;
    conn_rec *c = r->connection;
    sec_filter_in_ctx *ctx = NULL;

    sec_debug_log(r, 4, "sec_filter_in: start: inputmode=%i, readtype=%i, nBytes=%i", eMode, eBlock, nBytes);

    /* the context will always be supplied to us */
    if (!(ctx = f->ctx)) {
        sec_debug_log(r, 1, "sec_filter_in: context not found!");
        return ap_get_brigade(f->next, pbbOut, eMode, eBlock, nBytes);
    }

    /* Skip the call if there isn't any work left for us */
    if (ctx->done_writing == 1) {
        return ap_get_brigade(f->next, pbbOut, eMode, eBlock, nBytes);
    }

    if (ctx->type == POST_ON_DISK) {
        /* our data is stored on disk, here we create a small
         * buffer and open the file for reading
         */
        if (ctx->tmp_file_fd <= 0) {
            ctx->buffer = ctx->output_ptr = apr_palloc(r->pool, 4000);
            if (ctx->buffer == NULL) {
                sec_debug_log(r, 1, "sec_filter_in: Failed to allocate 4K bytes");
                return ap_get_brigade(f->next, pbbOut, eMode, eBlock, nBytes);
            }

            sec_debug_log(r, 4, "ctx->tmp_file_name \"%s\"", log_escape(r->pool, ctx->tmp_file_name));

            ctx->tmp_file_fd = open(ctx->tmp_file_name, O_RDONLY | O_BINARY);
            if (ctx->tmp_file_fd < 0) {
                sec_debug_log(r, 1, "sec_filter_in: Failed to open file \"%s\"", log_escape(r->pool, ctx->tmp_file_name));
                return ap_get_brigade(f->next, pbbOut, eMode, eBlock, nBytes);
            }
        }
    }

    /* Send a chunk of data further down the filter chain */
    if (ctx->output_sent < ctx->sofar) {
        apr_bucket *pbktOut;
        unsigned int len = 4000;

        /* We send 4000 bytes out in a go unless a smaller
         * size was requested by the caller. But we never
         * send more than 4000 bytes.
         */
        if (len > nBytes) len = (unsigned int)nBytes;

        /* we have fewer than $len bytes left */
        if (ctx->sofar - ctx->output_sent < len) len = ctx->sofar - ctx->output_sent;

        if (ctx->type == POST_ON_DISK) {
            int gotlen;

            /* read a chunk of the file into the buffer */
            gotlen = read(ctx->tmp_file_fd, ctx->output_ptr, len);
            if (gotlen <= 0) {
                sec_debug_log(r, 1, "sec_filter_in: Failed to read %i bytes from the tmp file [fd=%i, gotlen=%i, errno=%i (%s)]", len, ctx->tmp_file_fd, gotlen, errno, strerror(errno));
                return ap_get_brigade(f->next, pbbOut, eMode, eBlock, nBytes);
            } else {
                len = gotlen;
            }

            /* the third parameter, NULL, means "make a copy of the data" */
            pbktOut = apr_bucket_heap_create(ctx->output_ptr, len, NULL, c->bucket_alloc);

            /* we don't increase ctx->output_ptr here because
             * we are always using the same buffer
             */
            ctx->output_sent += len;
        }
        else {
            /* Can we lower memory consumption by using the same data
             * below, by supplying a non-NULL third parameter?
             */
            pbktOut = apr_bucket_heap_create(ctx->output_ptr, len, NULL, c->bucket_alloc);
            ctx->output_ptr += len;
            ctx->output_sent += len;
        }

        APR_BRIGADE_INSERT_TAIL(pbbOut, pbktOut);
        sec_debug_log(r, 4, "sec_filter_in: Sent %d bytes (%lu total)", len, ctx->output_sent);
    }

    /* are we done yet? */
    if (ctx->output_sent == ctx->sofar) {
        /* send an EOS bucket, we're done */
        apr_bucket *pbktOut = apr_bucket_eos_create(c->bucket_alloc);
        APR_BRIGADE_INSERT_TAIL(pbbOut, pbktOut);

        sec_debug_log(r, 4, "sec_filter_in: Sent EOS bucket");
        ctx->done_writing = 1;

        /* nothing left for us to do in this request */
        ap_remove_input_filter(f);

        if (ctx->type == POST_ON_DISK) {
            close(ctx->tmp_file_fd);
        }
    }

    return APR_SUCCESS;
}

static void sec_insert_filter(request_rec *r) {
    modsec_rec *msr = NULL;

    sec_debug_log(r, 9, "sec_insert_filter: Starting");

    msr = find_msr(r);
    if (msr == NULL) {
        sec_debug_log(r, 2, "sec_insert_filter: Skipping, msr is NULL (INTERNAL ERROR)");
        return;
    }

    if (msr->is_enabled != 1) {
        sec_debug_log(r, 2, "sec_insert_filter: Skipping, is_enabled is false");
        return;
    }
}

static void register_hooks(apr_pool_t *p) {
    static const char *init_before_list[] = {
        "mod_unique_id.c",
        "mod_ssl.c",
        NULL
    };
    static const char *init_after_list[] = {
        "mod_fcgid.c",
        "mod_cgid.c",
        NULL
    };

    ap_hook_post_config(sec_init, init_before_list, init_after_list, APR_HOOK_REALLY_LAST);
    ap_hook_log_transaction(sec_logger, NULL, NULL, APR_HOOK_MIDDLE);
    #ifdef ENABLE_EARLY_HOOK
    ap_hook_post_read_request(sec_check_access_early, NULL, NULL, APR_HOOK_FIRST);
    #endif
    ap_hook_fixups(sec_check_access, NULL, NULL, APR_HOOK_MIDDLE);
    ap_hook_child_init(sec_child_init, NULL, NULL, APR_HOOK_MIDDLE);
    ap_hook_insert_filter(sec_insert_filter, NULL, NULL, APR_HOOK_FIRST);
    global_sec_filter_in = ap_register_input_filter("MODSEC_IN", sec_filter_in, NULL, AP_FTYPE_CONTENT_SET) ;
}

module AP_MODULE_DECLARE_DATA log_post_module = {
   STANDARD20_MODULE_STUFF,
   sec_create_dir_config,        /* create per-dir    config structures */
   sec_merge_dir_config,         /* merge  per-dir    config structures */
   NULL,                         /* create per-server config structures */
   NULL,                         /* merge  per-server config structures */
   sec_cmds,                     /* table of config file commands       */
   register_hooks                /* register hooks                      */
};
